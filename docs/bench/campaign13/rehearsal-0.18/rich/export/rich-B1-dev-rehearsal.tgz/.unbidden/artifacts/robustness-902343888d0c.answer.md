```python
# file: tests/test_unbidden_robustness.py
import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from rich.markup import escape
from rich.control import strip_control_codes
from rich.control import escape_control_codes
from rich.cells import cell_len
from rich.cells import cached_cell_len
from rich.cells import split_text
from rich.filesize import decimal
from rich.emoji import Emoji


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_escape_never_crashes(s):
    escape(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_control_codes_never_crashes(s):
    strip_control_codes(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_escape_control_codes_never_crashes(s):
    escape_control_codes(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cell_len_never_crashes(s):
    cell_len(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cached_cell_len_never_crashes(s):
    cached_cell_len(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text(), pos=st.integers(min_value=-1000, max_value=10000))
def test_split_text_never_crashes(s, pos):
    split_text(s, pos)


@settings(max_examples=300, deadline=None)
@given(size=st.integers(min_value=-10**12, max_value=10**12))
def test_decimal_never_crashes(size):
    decimal(size)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_Emoji_replace_never_crashes(s):
    Emoji.replace(s)
```
