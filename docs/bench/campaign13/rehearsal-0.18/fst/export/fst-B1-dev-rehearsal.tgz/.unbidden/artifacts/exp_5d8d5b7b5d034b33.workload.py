from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any
import uuid

from sqlalchemy import insert, text
from sqlmodel import select

from app.core.config import settings
from app.models import Item, User


def build(client, db, normal_user_token_headers) -> Callable[[], Any]:
    # Find the ordinary test user created by init_db
    existing = db.exec(select(User).where(User.email == settings.EMAIL_TEST_USER)).first()
    if existing is None:
        raise RuntimeError("normal test user not found")
    normal_user_id = existing.id

    n_extra_users = 2000
    n_items = 200000

    base_time = datetime.now(UTC)

    # Create referenced rows first: users
    user_rows: list[dict] = []
    for i in range(n_extra_users):
        user_rows.append(
            {
                "id": uuid.uuid4(),
                "email": f"workload-user-{i:05d}@example.com",
                "hashed_password": "hashed-password-placeholder",
                "is_active": True,
                "is_superuser": False,
                "full_name": f"Workload User {i}",
                "created_at": base_time - timedelta(seconds=i),
            }
        )

    db.execute(insert(User), user_rows)
    db.commit()

    # All owner ids: normal user + new users
    owner_ids = [normal_user_id] + [r["id"] for r in user_rows]

    # Spread items evenly so each owner has a small share (~100 each)
    item_rows: list[dict] = []
    n_owners = len(owner_ids)
    for i in range(n_items):
        owner_id = owner_ids[i % n_owners]
        item_rows.append(
            {
                "id": uuid.uuid4(),
                "title": f"Workload item {i}",
                "description": f"Description for workload item {i}",
                "created_at": base_time - timedelta(seconds=i % 100000),
                "owner_id": owner_id,
            }
        )

    db.execute(insert(Item), item_rows)
    db.commit()

    db.execute(text("ANALYZE"))
    db.commit()

    headers = dict(normal_user_token_headers)
    url = "/api/v1/items/"

    def one_request():
        return client.get(url, headers=headers)

    return one_request
