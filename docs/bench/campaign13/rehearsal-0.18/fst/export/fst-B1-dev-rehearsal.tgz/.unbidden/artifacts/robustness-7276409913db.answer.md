```python
# file: tests/test_unbidden_robustness.py
from datetime import timedelta

import hypothesis.strategies as st
from hypothesis import given, settings

from app.core.security import create_access_token
from app.core.security import verify_password
from app.core.security import get_password_hash
from app.utils import send_email
from app.utils import generate_test_email
from app.utils import generate_reset_password_email
from app.utils import generate_new_account_email


@settings(max_examples=300, deadline=None)
@given(subject=st.text(), expires_delta=st.timedeltas())
def test_create_access_token_never_crashes(subject, expires_delta):
    create_access_token(subject=subject, expires_delta=expires_delta)


@settings(max_examples=300, deadline=None)
@given(plain=st.text(), hashed=st.text())
def test_verify_password_never_crashes(plain, hashed):
    assert isinstance(verify_password(plain, hashed), bool)


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_get_password_hash_round_trips(password):
    hashed = get_password_hash(password)
    assert isinstance(hashed, str)
    assert verify_password(password, hashed) is True


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), subject=st.text(), html_content=st.text())
def test_send_email_never_crashes(email_to, subject, html_content):
    send_email(email_to=email_to, subject=subject, html_content=html_content)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text())
def test_generate_test_email_never_crashes(email_to):
    generate_test_email(email_to)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), email=st.text(), token=st.text())
def test_generate_reset_password_email_never_crashes(email_to, email, token):
    generate_reset_password_email(email_to, email, token)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), username=st.text(), password=st.text())
def test_generate_new_account_email_never_crashes(email_to, username, password):
    generate_new_account_email(email_to, username, password)
```
