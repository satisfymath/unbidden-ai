import uuid
from collections.abc import Callable
from datetime import UTC, datetime

from sqlalchemy import insert
from sqlmodel import select

from app.core.config import settings
from app.models import Item, User


def build(client, db, normal_user_token_headers) -> Callable:
    # Find the ordinary test user that the headers authenticate as
    statement = select(User).where(User.email == settings.EMAIL_TEST_USER)
    test_user = db.exec(statement).first()
    if test_user is None:
        raise RuntimeError("test user not found")
    test_user_id = test_user.id

    # Seed once: skip if already seeded
    try:
        from sqlmodel import func as _func

        existing = db.exec(select(_func.count()).select_from(Item)).one()
        already_seeded = existing is not None and int(existing) >= 200000
    except Exception:
        already_seeded = False

    if not already_seeded:
        now = datetime.now(UTC)
        n_users = 2000
        per_user = 100

        user_rows: list[dict] = []
        user_ids: list[uuid.UUID] = []
        for i in range(n_users):
            uid = uuid.uuid4()
            user_ids.append(uid)
            user_rows.append(
                {
                    "id": uid,
                    "email": f"workload-user-{i}@example.com",
                    "hashed_password": "hashed-password-placeholder",
                    "is_active": True,
                    "is_superuser": False,
                    "full_name": f"Workload User {i}",
                    "created_at": now,
                }
            )
        db.execute(insert(User), user_rows)

        # Build item rows spread over synthetic users + the normal test user
        # 2000 * 100 = 200000 plus 100 for test user = 200100 total
        owners: list[uuid.UUID] = list(user_ids) + [test_user_id]
        # total items: len(owners) would be 2001; we want >=200000
        # give each synthetic user 100 items and test user 100 items
        item_rows: list[dict] = []
        idx = 0
        for owner in owners:
            for _ in range(per_user):
                item_rows.append(
                    {
                        "id": uuid.uuid4(),
                        "title": f"workload item {idx}",
                        "description": f"description {idx}",
                        "created_at": now,
                        "owner_id": owner,
                    }
                )
                idx += 1
        db.execute(insert(Item), item_rows)
        db.commit()
        try:
            db.exec_driver_sql("ANALYZE")
        except Exception:
            pass
        try:
            db.commit()
        except Exception:
            pass
    else:
        # Ensure test user owns some rows even when skipping reseed
        cnt = db.exec(
            select(Item.id).where(Item.owner_id == test_user_id).limit(1)
        ).first()
        if cnt is None:
            now2 = datetime.now(UTC)
            extra = [
                {
                    "id": uuid.uuid4(),
                    "title": f"workload item extra {i}",
                    "description": f"description extra {i}",
                    "created_at": now2,
                    "owner_id": test_user_id,
                }
                for i in range(100)
            ]
            db.execute(insert(Item), extra)
            db.commit()
            try:
                db.exec_driver_sql("ANALYZE")
            except Exception:
                pass

    headers = normal_user_token_headers

    def one():
        return client.get("/api/v1/items/", headers=headers)

    return one
