from datetime import timedelta

from hypothesis import given, settings, strategies as st

from app.core.security import create_access_token
from app.core.security import get_password_hash
from app.core.security import verify_password
from app.utils import generate_new_account_email
from app.utils import generate_reset_password_email
from app.utils import generate_test_email
from app.utils import render_email_template
from app.utils import send_email


@settings(max_examples=300, deadline=None)
@given(password=st.text(max_size=100))
def test_get_password_hash_round_trips(password):
    hashed = get_password_hash(password)
    assert verify_password(password, hashed)


@settings(max_examples=300, deadline=None)
@given(plain_password=st.text(), hashed_password=st.text())
def test_verify_password_never_crashes(plain_password, hashed_password):
    verify_password(plain_password, hashed_password)


@settings(max_examples=300, deadline=None)
@given(subject=st.text(), expires_delta=st.timedeltas())
def test_create_access_token_never_crashes(subject, expires_delta):
    create_access_token(subject, expires_delta)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text())
def test_generate_test_email_never_crashes(email_to):
    generate_test_email(email_to)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), email=st.text(), token=st.text())
def test_generate_reset_password_email_never_crashes(email_to, email, token):
    generate_reset_password_email(email_to, email, token)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), username=st.text(), password=st.text())
def test_generate_new_account_email_never_crashes(email_to, username, password):
    generate_new_account_email(email_to, username, password)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), subject=st.text(), html_content=st.text())
def test_send_email_never_crashes(email_to, subject, html_content):
    send_email(email_to=email_to, subject=subject, html_content=html_content)


@settings(max_examples=300, deadline=None)
@given(template_name=st.text(), context=st.dictionaries(st.text(), st.text() | st.integers() | st.booleans() | st.none()))
def test_render_email_template_never_crashes(template_name, context):
    render_email_template(template_name=template_name, context=context)
