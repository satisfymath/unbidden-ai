```python
# file: tests/test_unbidden_robustness.py
from datetime import timedelta
from hypothesis import given, settings, strategies as st
from app.core.security import create_access_token
from app.core.security import verify_password
from app.core.security import get_password_hash
from app.utils import render_email_template
from app.utils import send_email
from app.utils import generate_test_email
from app.utils import generate_reset_password_email
from app.utils import generate_new_account_email


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_get_password_hash_never_crashes(password):
    get_password_hash(password)


@settings(max_examples=300, deadline=None)
@given(plain=st.text(), fake_hash=st.text())
def test_verify_password_round_trips(plain, fake_hash):
    hashed = get_password_hash(plain)
    assert verify_password(plain, hashed) is True
    verify_password(plain, fake_hash)
    verify_password(fake_hash, hashed)


@settings(max_examples=300, deadline=None)
@given(subject=st.text(), expires_delta=st.timedeltas())
def test_create_access_token_never_crashes(subject, expires_delta):
    create_access_token(subject, expires_delta)


@settings(max_examples=300, deadline=None)
@given(
    template_name=st.text(),
    context=st.dictionaries(
        st.text(),
        st.one_of(st.text(), st.integers(), st.booleans(), st.none(), st.floats(allow_nan=False, allow_infinity=False)),
    ),
)
def test_render_email_template_never_crashes(template_name, context):
    render_email_template(template_name=template_name, context=context)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), subject=st.text(), html_content=st.text())
def test_send_email_never_crashes(email_to, subject, html_content):
    send_email(email_to=email_to, subject=subject, html_content=html_content)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text())
def test_generate_test_email_never_crashes(email_to):
    generate_test_email(email_to)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), email=st.text(), token=st.text())
def test_generate_reset_password_email_never_crashes(email_to, email, token):
    generate_reset_password_email(email_to=email_to, email=email, token=token)


@settings(max_examples=300, deadline=None)
@given(email_to=st.text(), username=st.text(), password=st.text())
def test_generate_new_account_email_never_crashes(email_to, username, password):
    generate_new_account_email(email_to=email_to, username=username, password=password)
```