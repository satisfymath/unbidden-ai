from pathlib import Path

from hypothesis import given, settings, strategies as st

from harlequin.autocomplete.symbols import find_symbols
from harlequin.bindings import key_needs_priority
from harlequin.crash import write_crash_report
from harlequin.exception import pretty_print_warning
from harlequin.export import names_a_directory
from harlequin.external import split_command
from harlequin.hsql.diagnostics import error
from harlequin.hsql.diagnostics import note


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_find_symbols_never_crashes(text):
    find_symbols(text)


@settings(max_examples=300, deadline=None)
@given(key=st.text())
def test_key_needs_priority_never_crashes(key):
    key_needs_priority(key)


@settings(max_examples=300, deadline=None)
@given(command=st.text())
def test_split_command_never_crashes(command):
    split_command(command)


@settings(max_examples=300, deadline=None)
@given(title=st.text(), message=st.text())
def test_pretty_print_warning_never_crashes(title, message):
    pretty_print_warning(title, message)


@settings(max_examples=300, deadline=None)
@given(message=st.text())
def test_error_never_crashes(message):
    error(message)


@settings(max_examples=300, deadline=None)
@given(message=st.text())
def test_note_never_crashes(message):
    note(message)


@settings(max_examples=300, deadline=None)
@given(destination=st.one_of(st.text(), st.builds(Path, st.text())))
def test_names_a_directory_never_crashes(destination):
    names_a_directory(destination)


@settings(max_examples=300, deadline=None)
@given(report=st.text())
def test_write_crash_report_never_crashes(report):
    write_crash_report(report)
