import hashlib
from jwt.algorithms import Algorithm
from jwt.algorithms import HMACAlgorithm
from jwt.api_jws import PyJWS
from jwt.jwk_set_cache import JWKSetCache
from jwt.utils import base64url_decode
from jwt.utils import base64url_encode
from jwt.utils import bytes_to_number
from jwt.utils import force_bytes
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.binary(), st.text()))
def test_force_bytes_never_crashes(data):
    result = force_bytes(data)
    assert isinstance(result, bytes)
    if isinstance(data, str):
        assert result == data.encode("utf-8")


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_encode_round_trips(data):
    encoded = base64url_encode(data)
    assert isinstance(encoded, bytes)
    assert base64url_decode(encoded) == data


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_bytes_to_number_never_crashes(data):
    result = bytes_to_number(data)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.binary(), st.text()))
def test_prepare_key_never_crashes(data):
    alg = HMACAlgorithm(hashlib.sha256)
    result = alg.prepare_key(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.binary(), st.text()))
def test_to_jwk_never_crashes(data):
    alg = HMACAlgorithm(hashlib.sha256)
    result = alg.to_jwk(data, as_dict=True)
    assert isinstance(result, dict)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_compute_hash_digest_never_crashes(data):
    alg = Algorithm(hashlib.sha256)
    result = alg.compute_hash_digest(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.none(), st.dictionaries(st.text(), st.one_of(st.none(), st.booleans(), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.text(), st.binary()))))
def test_put_never_crashes(data):
    cache = JWKSetCache(3600)
    cache.put(data)


@settings(max_examples=300, deadline=None)
@given(alg_id=st.text())
def test_register_algorithm_never_crashes(alg_id):
    jws = PyJWS()
    alg_obj = HMACAlgorithm(hashlib.sha256)
    jws.register_algorithm(alg_id, alg_obj)
