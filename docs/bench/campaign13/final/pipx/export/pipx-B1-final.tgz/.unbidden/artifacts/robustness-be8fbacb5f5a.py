from pathlib import Path

from hypothesis import given, settings
import hypothesis.strategies as st

from pipx.commands.common import add_suffix
from pipx.commands.common import exposed_app_names
from pipx.redact import redact_command_line
from pipx.redact import redact_url_credentials
from pipx.main import package_is_path
from pipx.util import full_package_description
from pipx.util import is_file_name
from pipx.commands.run_uv import translate_pip_args_for_uv


@settings(max_examples=300, deadline=None)
@given(name=st.text(), suffix=st.text())
def test_add_suffix_never_crashes(name, suffix):
    add_suffix(name, suffix)


@settings(max_examples=300, deadline=None)
@given(name=st.text(), suffix=st.text())
def test_exposed_app_names_never_crashes(name, suffix):
    exposed_app_names(name, suffix)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_redact_url_credentials_never_crashes(text):
    redact_url_credentials(text)


@settings(max_examples=300, deadline=None)
@given(cmd=st.lists(st.text()))
def test_redact_command_line_never_crashes(cmd):
    redact_command_line(cmd)


@settings(max_examples=300, deadline=None)
@given(name=st.text())
def test_is_file_name_never_crashes(name):
    is_file_name(name)


@settings(max_examples=300, deadline=None)
@given(name=st.text(), spec=st.text())
def test_full_package_description_never_crashes(name, spec):
    full_package_description(name, spec)


@settings(max_examples=300, deadline=None)
@given(package=st.text())
def test_package_is_path_never_crashes(package):
    package_is_path(package)


@settings(max_examples=300, deadline=None)
@given(args=st.lists(st.text()))
def test_translate_pip_args_for_uv_never_crashes(args):
    translate_pip_args_for_uv(args)
