from reader._app.legacy import humanize_apnumber
from reader._app.legacy import highlighted
from reader._plugins.legacy.share import percent_encode
from reader._update.hooks import log_resource_id
from reader.plugins.entry_dedupe import tokenize
from reader.plugins.entry_dedupe import strip_accents
from reader.types import HighlightedString
from reader._app.legacy.api_thing import is_safe_url
from hypothesis import given, settings, assume
from hypothesis import strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.integers())
def test_humanize_apnumber_never_crashes(value):
    humanize_apnumber(value)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_highlighted_never_crashes(s):
    highlighted(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_percent_encode_never_crashes(s):
    percent_encode(s)


@settings(max_examples=300, deadline=None)
@given(resource_id=st.one_of(st.none(), st.lists(st.text()).map(tuple)))
def test_log_resource_id_never_crashes(resource_id):
    log_resource_id(resource_id)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_tokenize_never_crashes(s):
    tokenize(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_accents_never_crashes(s):
    strip_accents(s)


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text(), c=st.text())
def test_HighlightedString_extract_round_trips(a, b, c):
    before = "<mark>"
    after = "</mark>"
    assume(before not in a and before not in b and before not in c)
    assume(after not in a and after not in b and after not in c)
    text = a + before + b + after + c
    hs = HighlightedString.extract(text, before, after)
    assert hs.apply(before, after) == text


@settings(max_examples=300, deadline=None)
@given(target=st.text())
def test_is_safe_url_never_crashes(target):
    is_safe_url(target)
