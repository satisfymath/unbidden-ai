from marshmallow.utils import ensure_text_type
from marshmallow.utils import is_generator
from marshmallow.utils import is_iterable_but_not_string
from marshmallow.orderedset import OrderedSet
from marshmallow.fields import Field
from marshmallow.exceptions import ValidationError
from marshmallow.decorators import validates
from marshmallow.decorators import set_hook
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(val=st.text())
def test_ensure_text_type_never_crashes(val):
    assert isinstance(ensure_text_type(val), str)
    assert ensure_text_type(val.encode("utf-8")) == val


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.text(), st.integers(), st.lists(st.integers()), st.dictionaries(st.text(), st.integers()), st.none(), st.booleans()))
def test_is_generator_never_crashes(obj):
    assert isinstance(is_generator(obj), bool)


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.text(), st.binary(), st.integers(), st.lists(st.text()), st.tuples(st.integers()), st.dictionaries(st.text(), st.text()), st.none()))
def test_is_iterable_but_not_string_never_crashes(obj):
    assert isinstance(is_iterable_but_not_string(obj), bool)


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.integers(min_value=-10**18, max_value=10**18)))
def test_OrderedSet_add_never_crashes(key):
    s = OrderedSet()
    s.add(key)


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.integers(min_value=-10**18, max_value=10**18)))
def test_OrderedSet_discard_never_crashes(key):
    s = OrderedSet()
    s.discard(key)


@settings(max_examples=300, deadline=None)
@given(key=st.text())
def test_Field_make_error_never_crashes(key):
    f = Field()
    if key in f.error_messages:
        try:
            f.make_error(key)
        except ValidationError:
            pass
        else:
            raise AssertionError("make_error with valid key must raise ValidationError")
    else:
        try:
            f.make_error(key)
        except AssertionError:
            pass
        else:
            raise AssertionError("make_error with unknown key must raise AssertionError")


@settings(max_examples=300, deadline=None)
@given(msg=st.one_of(st.text(), st.lists(st.text()), st.dictionaries(st.text(), st.lists(st.text()))))
def test_ValidationError_normalized_messages_never_crashes(msg):
    e = ValidationError(msg)
    e.normalized_messages()


@settings(max_examples=300, deadline=None)
@given(names=st.lists(st.text()))
def test_validates_never_crashes(names):
    validates(*names)
