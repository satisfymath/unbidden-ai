from hypothesis import given, settings, strategies as st

from aegra_api.core.sse import format_sse_message
from aegra_api.core.sse import create_metadata_event
from aegra_api.core.sse import create_end_event
from aegra_api.services.event_streaming.channels import is_supported_channel
from aegra_api.services.event_streaming.normalizers import normalize_state_payload
from aegra_api.utils.sse_utils import generate_event_id
from aegra_api.utils.sse_utils import extract_event_sequence
from aegra_api.settings import parse_lower
from aegra_api.services.run_waiters import error_envelope

json_like = st.recursive(
    st.one_of(st.text(), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.booleans(), st.none()),
    lambda children: st.one_of(
        st.lists(children),
        st.dictionaries(st.text(), children),
    ),
)


@settings(max_examples=300, deadline=None)
@given(event=st.text(), data=json_like, event_id=st.one_of(st.none(), st.text()))
def test_format_sse_message_never_crashes(event, data, event_id):
    result = format_sse_message(event, data, event_id=event_id)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(run_id=st.text(), event_id=st.one_of(st.none(), st.text()), attempt=st.integers())
def test_create_metadata_event_never_crashes(run_id, event_id, attempt):
    result = create_metadata_event(run_id, event_id=event_id, attempt=attempt)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(event_id=st.one_of(st.none(), st.text()), status=st.text())
def test_create_end_event_never_crashes(event_id, status):
    result = create_end_event(event_id=event_id, status=status)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(channel=st.text())
def test_is_supported_channel_never_crashes(channel):
    result = is_supported_channel(channel)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(value=json_like)
def test_normalize_state_payload_never_crashes(value):
    normalize_state_payload(value)


@settings(max_examples=300, deadline=None)
@given(run_id=st.text().filter(lambda s: "_event_" not in s), sequence=st.integers())
def test_generate_event_id_round_trips(run_id, sequence):
    event_id = generate_event_id(run_id, sequence)
    assert isinstance(event_id, str)
    assert extract_event_sequence(event_id) == sequence


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_lower_never_crashes(value):
    result = parse_lower(value)
    assert isinstance(result, str)
    assert result == value.strip().lower()


@settings(max_examples=300, deadline=None)
@given(error=st.text(), message=st.text())
def test_error_envelope_never_crashes(error, message):
    result = error_envelope(error, message)
    assert result is not None
