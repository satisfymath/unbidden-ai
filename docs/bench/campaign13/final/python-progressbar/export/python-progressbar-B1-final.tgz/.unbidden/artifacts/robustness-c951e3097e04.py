import datetime

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from progressbar.env import env_flag
from progressbar.terminal.base import clear_line
from progressbar.terminal.base import get_color
from progressbar.utils import no_color
from progressbar.utils import len_color
from progressbar.utils import deltas_to_seconds
from progressbar.widgets import format_unit_value
from progressbar.widgets import create_wrapper


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_no_color_never_crashes(value):
    no_color(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_len_color_never_crashes(value):
    len_color(value)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.none(),
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(allow_nan=False, allow_infinity=False, min_value=-1e12, max_value=1e12),
    ),
    unit=st.text(),
    unit_scale=st.booleans(),
)
def test_format_unit_value_never_crashes(value, unit, unit_scale):
    format_unit_value(value, unit=unit, unit_scale=unit_scale)


@settings(max_examples=300, deadline=None)
@given(
    d1=st.one_of(
        st.none(),
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(allow_nan=False, allow_infinity=False, min_value=-1e12, max_value=1e12),
        st.timedeltas(min_value=datetime.timedelta(days=-10000), max_value=datetime.timedelta(days=10000)),
    ),
    d2=st.one_of(
        st.none(),
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(allow_nan=False, allow_infinity=False, min_value=-1e12, max_value=1e12),
        st.timedeltas(min_value=datetime.timedelta(days=-10000), max_value=datetime.timedelta(days=10000)),
    ),
    default=st.one_of(
        st.floats(allow_nan=False, allow_infinity=False, min_value=-1e9, max_value=1e9),
        st.integers(min_value=-10**9, max_value=10**9),
    ),
)
def test_deltas_to_seconds_never_crashes(d1, d2, default):
    deltas_to_seconds(d1, d2, default=default)


@settings(max_examples=300, deadline=None)
@given(name=st.text(), default=st.one_of(st.booleans(), st.none()))
def test_env_flag_never_crashes(name, default):
    env_flag(name, default)


@settings(max_examples=300, deadline=None)
@given(n=st.integers(min_value=-1000000, max_value=1000000))
def test_clear_line_never_crashes(n):
    clear_line(n)


@settings(max_examples=300, deadline=None)
@given(
    value=st.floats(allow_nan=False, allow_infinity=False, min_value=-1000000.0, max_value=1000000.0),
    color=st.just(None),
)
def test_get_color_never_crashes(value, color):
    get_color(value, color)


@settings(max_examples=300, deadline=None)
@given(
    wrapper_arg=st.one_of(
        st.none(),
        st.text(),
        st.tuples(
            st.one_of(st.none(), st.text()),
            st.one_of(st.none(), st.text()),
        ),
    )
)
def test_create_wrapper_never_crashes(wrapper_arg):
    create_wrapper(wrapper_arg)
