from dinkydash.accounts import normalise
from dinkydash.attribution import from_cookie
from dinkydash.attribution import from_mapping
from dinkydash.calendars import normalise_url
from dinkydash.clock import clock_of
from dinkydash.screens import looks_like_a_token
from dinkydash.sentry import options
from dinkydash.sentry import scrub_text
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_scrub_text_never_crashes(value):
    scrub_text(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_looks_like_a_token_never_crashes(value):
    looks_like_a_token(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_normalise_never_crashes(value):
    normalise(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_from_cookie_never_crashes(value):
    from_cookie(value)


@settings(max_examples=300, deadline=None)
@given(value=st.dictionaries(st.text(), st.one_of(st.text(), st.integers(), st.none(), st.booleans())))
def test_from_mapping_never_crashes(value):
    from_mapping(value)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.dictionaries(st.text(), st.one_of(st.text(), st.integers(), st.none())), st.dictionaries(st.text(), st.text())))
def test_clock_of_never_crashes(value):
    clock_of(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_normalise_url_never_crashes(value):
    normalise_url(value)


@settings(max_examples=300, deadline=None)
@given(dsn=st.text(), environment=st.one_of(st.none(), st.text()), release=st.one_of(st.none(), st.text()))
def test_options_never_crashes(dsn, environment, release):
    options(dsn, environment=environment, release=release)
