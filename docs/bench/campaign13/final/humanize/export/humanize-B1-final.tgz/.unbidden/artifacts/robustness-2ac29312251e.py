from humanize.filesize import naturalsize
from humanize.number import ordinal
from humanize.number import intcomma
from humanize.number import intword
from humanize.number import apnumber
from humanize.number import fractional
from humanize.time import naturaldelta
from humanize.lists import natural_list
from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
        st.integers().map(str),
    ),
    binary=st.booleans(),
    gnu=st.booleans(),
    format=st.sampled_from(["%.1f", "%.2f", "%.0f", "%d"]),
)
def test_naturalsize_never_crashes(value, binary, gnu, format):
    naturalsize(value, binary=binary, gnu=gnu, format=format)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(st.integers(), st.integers().map(str)),
    gender=st.sampled_from(["male", "female"]),
)
def test_ordinal_never_crashes(value, gender):
    ordinal(value, gender=gender)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
        st.integers().map(str),
    ),
    ndigits=st.one_of(st.none(), st.integers(min_value=0, max_value=10)),
)
def test_intcomma_never_crashes(value, ndigits):
    intcomma(value, ndigits=ndigits)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
        st.integers().map(str),
    ),
    format=st.sampled_from(["%.1f", "%.2f", "%.0f", "%d"]),
)
def test_intword_never_crashes(value, format):
    intword(value, format=format)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.integers(), st.integers().map(str)))
def test_apnumber_never_crashes(value):
    apnumber(value)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
        st.integers().map(str),
    )
)
def test_fractional_never_crashes(value):
    fractional(value)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
        st.timedeltas(min_value=st.timedeltas(min_value=-1000000, max_value=1000000).example().__class__.min if False else None) if False else st.timedeltas(),
    ),
    months=st.booleans(),
    minimum_unit=st.sampled_from(["seconds", "minutes", "hours", "days", "months", "years"]),
)
def test_naturaldelta_never_crashes(value, months, minimum_unit):
    naturaldelta(value, months=months, minimum_unit=minimum_unit)


@settings(max_examples=300, deadline=None)
@given(items=st.lists(st.text(), max_size=10))
def test_natural_list_never_crashes(items):
    natural_list(items)
