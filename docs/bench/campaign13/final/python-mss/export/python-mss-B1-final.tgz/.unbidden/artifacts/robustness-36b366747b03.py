import zlib
from pathlib import Path

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from mss.tools import to_png
from mss.tools import parse_edid
from mss.screenshot import ScreenShot
from mss.models import Monitor
from mss.buffer import finalizing_buffer
from mss.linux import choose_impl


def _noop_finalizer(*args, **kwargs):
    return None


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=16),
    height=st.integers(min_value=1, max_value=16),
    level=st.integers(min_value=0, max_value=9),
    extra=st.binary(max_size=8),
)
def test_to_png_never_crashes(width, height, level, extra):
    size = (width, height)
    n = width * height * 4
    data = (extra * ((n // max(1, len(extra))) + 1))[:n] if extra else bytes(n)
    if len(data) < n:
        data = data + bytes(n - len(data))
    out = to_png(bytes(data), size, level=level, output=None)
    assert isinstance(out, bytes)
    assert len(out) > 0


@settings(max_examples=300, deadline=None)
@given(data=st.binary(max_size=512))
def test_parse_edid_never_crashes(data):
    result = parse_edid(data)
    assert result is not None


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=16),
    height=st.integers(min_value=1, max_value=16),
    payload=st.binary(min_size=0, max_size=1024),
)
def test_from_size_never_crashes(width, height, payload):
    n = width * height * 4
    if len(payload) < n:
        payload = payload + bytes(n - len(payload))
    else:
        payload = payload[:n]
    shot = ScreenShot.from_size(bytes(payload), width, height)
    assert shot.width == width
    assert shot.height == height


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=8),
    height=st.integers(min_value=1, max_value=8),
    mode=st.sampled_from(["RGB", "RGBA"]),
    payload=st.binary(min_size=0, max_size=512),
)
def test_to_pil_never_crashes(width, height, mode, payload):
    n = width * height * 4
    if len(payload) < n:
        payload = payload + bytes(n - len(payload))
    else:
        payload = payload[:n]
    shot = ScreenShot.from_size(bytes(payload), width, height)
    img = shot.to_pil(mode=mode)
    assert img is not None


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=8),
    height=st.integers(min_value=1, max_value=8),
    payload=st.binary(min_size=0, max_size=512),
)
def test_bgra_never_crashes(width, height, payload):
    n = width * height * 4
    if len(payload) < n:
        payload = payload + bytes(n - len(payload))
    else:
        payload = payload[:n]
    shot = ScreenShot.from_size(bytes(payload), width, height)
    val = shot.bgra
    if callable(val):
        val = val()
    assert val is not None


@settings(max_examples=300, deadline=None)
@given(
    left=st.integers(min_value=-10000, max_value=10000),
    top=st.integers(min_value=-10000, max_value=10000),
    width=st.integers(min_value=0, max_value=10000),
    height=st.integers(min_value=0, max_value=10000),
)
def test_as_region_never_crashes(left, top, width, height):
    mon = {"left": left, "top": top, "width": width, "height": height}
    region = Monitor.as_region(mon)
    assert region is not None


@settings(max_examples=300, deadline=None)
@given(data=st.binary(max_size=1024))
def test_finalizing_buffer_never_crashes(data):
    buf = finalizing_buffer(bytes(data), _noop_finalizer)
    assert buf is not None


@settings(max_examples=300, deadline=None)
@given(backend=st.sampled_from(["default"]))
def test_choose_impl_never_crashes(backend):
    impl = choose_impl(backend)
    assert impl is not None
