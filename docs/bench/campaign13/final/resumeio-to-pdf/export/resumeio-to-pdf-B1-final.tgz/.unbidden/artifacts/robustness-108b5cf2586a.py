import string
from hypothesis import given, settings, strategies as st
import pytest
from resumeio_to_pdf.services.assets import find_worker_name
from resumeio_to_pdf.services.assets import find_rendering_core_url
from resumeio_to_pdf.services.assets import find_chunk_names
from resumeio_to_pdf.api.api import pdf_filename


@settings(max_examples=300, deadline=None)
@given(prefix=st.text(), middle=st.text(), suffix=st.text())
def test_find_worker_name_never_crashes(prefix, middle, suffix):
    rendering_core = f'{prefix}importScripts("worker-{middle}.js"){suffix}'
    result = find_worker_name(rendering_core)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(prefix=st.text(), middle=st.text(), suffix=st.text())
def test_find_rendering_core_url_never_crashes(prefix, middle, suffix):
    builder_bundle = f'{prefix}src="static/js/rendering-core-{middle}.js"{suffix}'
    result = find_rendering_core_url(builder_bundle)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(prefix=st.text(), middle=st.text(), suffix=st.text())
def test_find_chunk_names_never_crashes(prefix, middle, suffix):
    worker = f'{prefix}import("./chunk-{middle}.js");import("static/chunk.js"){suffix}'
    result = find_chunk_names(worker)
    assert isinstance(result, (list, tuple, set, frozenset))


@settings(max_examples=300, deadline=None)
@given(document=st.dictionaries(st.text(), st.text() | st.integers(min_value=-10**18, max_value=10**18) | st.none() | st.booleans(), max_size=10))
def test_pdf_filename_never_crashes(document):
    result = pdf_filename(document)
    assert isinstance(result, str)
