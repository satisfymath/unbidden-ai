import pytest
from hypothesis import given, settings, strategies as st
from dooit.backport.migrate_from_v2 import parse_recurrence
from dooit.backport.migrate_from_v2 import parse_due
from dooit.utils.date_parser import parse
from dooit.ui.widgets.inputs.model_inputs import Recurrence
from dooit.ui.api.event_handlers import timer
from dooit.ui.api.api_components.vars import VarManager
from dooit.ui.api.api_components.keys import KeyManager
from dooit.ui.api.api_components.formatters.formatter_store import FormatterStore


@settings(max_examples=300, deadline=None)
@given(recurrence=st.text())
def test_parse_recurrence_never_crashes(recurrence):
    parse_recurrence(recurrence)


@settings(max_examples=300, deadline=None)
@given(due=st.text())
def test_parse_due_never_crashes(due):
    parse_due(due)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_never_crashes(value):
    parse(value)


@settings(max_examples=300, deadline=None)
@given(recurrence=st.text())
def test_Recurrence_parse_recurrence_never_crashes(recurrence):
    Recurrence.parse_recurrence(recurrence)


@settings(max_examples=300, deadline=None)
@given(interval=st.floats(allow_nan=True, allow_infinity=True))
def test_timer_never_crashes(interval):
    timer(interval)


@settings(max_examples=300, deadline=None)
@given(value=st.booleans())
def test_always_expand_workspaces_never_crashes(value):
    VarManager().always_expand_workspaces(value)


@settings(max_examples=300, deadline=None)
@given(key=st.text())
def test_register_key_never_crashes(key):
    KeyManager().register_key(key)


@settings(max_examples=300, deadline=None)
@given(_id=st.text())
def test_remove_never_crashes(_id):
    FormatterStore().remove(_id)
