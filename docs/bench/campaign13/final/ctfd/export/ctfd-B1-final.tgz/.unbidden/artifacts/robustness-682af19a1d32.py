import configparser

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from CTFd.config import EnvInterpolation
from CTFd.config import process_string_var
from CTFd.config import empty_str_cast
from CTFd.constants import RawEnum
from CTFd.utils.config.pages import format_variables
from CTFd.utils.helpers import markup
from CTFd.utils.encoding import hexencode
from CTFd.utils.encoding import hexdecode
from CTFd.utils.encoding import base64encode
from CTFd.utils.encoding import base64decode


@settings(max_examples=300, deadline=None)
@given(value=st.text(), key=st.one_of(st.text(), st.none()))
def test_process_string_var_never_crashes(value, key):
    process_string_var(value, key)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(st.text(), st.integers(), st.none()),
    default=st.one_of(st.text(), st.integers(), st.none()),
)
def test_empty_str_cast_never_crashes(value, default):
    empty_str_cast(value, default)


@settings(max_examples=300, deadline=None)
@given(content=st.text())
def test_format_variables_never_crashes(content):
    format_variables(content)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_markup_never_crashes(text):
    markup(text)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_hexencode_round_trips(s):
    enc = hexencode(s)
    dec = hexdecode(enc)
    assert dec == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_base64encode_round_trips(s):
    enc = base64encode(s)
    dec = base64decode(enc)
    assert dec == s


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.text(), st.integers(), st.none()))
def test_RawEnum_test_never_crashes(value):
    RawEnum.test(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text(), section=st.text(), option=st.text())
def test_before_get_never_crashes(value, section, option):
    interp = EnvInterpolation()
    interp.before_get(None, section, option, value, None)
