```python
# file: tests/test_unbidden_robustness.py
from oauthlib.common import quote
from oauthlib.common import unquote
from oauthlib.common import generate_token
from oauthlib.common import generate_client_id
from oauthlib.oauth1.rfc5849.signature import signature_base_string
from oauthlib.oauth2.rfc6749.utils import list_to_scope
from oauthlib.oauth2.rfc6749.utils import scope_to_list
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_verifier
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_challenge
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(s=st.text(), safe=st.binary(max_size=8))
def test_quote_round_trips(s, safe):
    q = quote(s, safe=safe)
    assert isinstance(q, str)
    assert unquote(q) == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    result = unquote(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=100), chars=st.text(min_size=1, max_size=64))
def test_generate_token_never_crashes(length, chars):
    token = generate_token(length=length, chars=chars)
    assert isinstance(token, str)
    assert len(token) == length


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=100))
def test_generate_client_id_never_crashes(length):
    cid = generate_client_id(length=length)
    assert isinstance(cid, str)
    assert len(cid) == length


@settings(max_examples=300, deadline=None)
@given(
    http_method=st.text(),
    base_str_uri=st.text(),
    normalized_encoded_request_parameters=st.text(),
)
def test_signature_base_string_never_crashes(http_method, base_str_uri, normalized_encoded_request_parameters):
    result = signature_base_string(http_method, base_str_uri, normalized_encoded_request_parameters)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(scope=st.one_of(st.none(), st.lists(st.text(), max_size=10)))
def test_list_to_scope_never_crashes(scope):
    result = list_to_scope(scope)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(scope=st.one_of(st.none(), st.text()))
def test_scope_to_list_never_crashes(scope):
    result = scope_to_list(scope)
    assert result is None or isinstance(result, list)


@settings(max_examples=300, deadline=None)
@given(code_verifier=st.text())
def test_is_valid_code_verifier_never_crashes(code_verifier):
    result = is_valid_code_verifier(code_verifier)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(code_challenge=st.text(), code_challenge_method=st.sampled_from(["plain", "S256"]))
def test_is_valid_code_challenge_never_crashes(code_challenge, code_challenge_method):
    result = is_valid_code_challenge(code_challenge, code_challenge_method)
    assert isinstance(result, bool)
```
