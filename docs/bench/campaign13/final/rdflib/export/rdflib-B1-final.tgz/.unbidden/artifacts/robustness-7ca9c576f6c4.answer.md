```python
# file: tests/test_unbidden_robustness.py
from rdflib.compat import cast_bytes
from rdflib.contrib.graphdb.util import sanitize_filename
from rdflib.contrib.graphdb.util import extract_filename_from_content_disposition
from rdflib.contrib.graphdb.util import infer_filename_from_fileobj
from rdflib.plugins.parsers.notation3 import join
from rdflib.plugins.parsers.notation3 import splitFragP
from rdflib.plugins.parsers.ntriples import unquote
from rdflib.plugins.parsers.ntriples import uriquote
import types
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cast_bytes_round_trips(s):
    result = cast_bytes(s)
    assert isinstance(result, bytes)
    assert result.decode("utf-8") == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_sanitize_filename_never_crashes(s):
    sanitize_filename(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_extract_filename_from_content_disposition_never_crashes(s):
    extract_filename_from_content_disposition(s)


@settings(max_examples=300, deadline=None)
@given(
    fallback=st.text(),
    name=st.one_of(
        st.text(),
        st.binary(),
        st.integers(min_value=-(10**18), max_value=10**18),
        st.none(),
    ),
)
def test_infer_filename_from_fileobj_never_crashes(fallback, name):
    file_obj = types.SimpleNamespace(name=name)
    infer_filename_from_fileobj(file_obj, fallback)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    unquote(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_uriquote_never_crashes(s):
    uriquote(s)


@settings(max_examples=300, deadline=None)
@given(here=st.text(), there=st.text())
def test_join_never_crashes(here, there):
    join(here, there)


@settings(max_examples=300, deadline=None)
@given(s=st.text(), punc=st.integers(min_value=-(10**9), max_value=10**9))
def test_splitFragP_never_crashes(s, punc):
    splitFragP(s, punc)
```