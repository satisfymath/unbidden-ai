from hypothesis import given, settings, strategies as st
import datetime

from progressbar.utils import no_color
from progressbar.utils import len_color
from progressbar.widgets import create_wrapper
from progressbar.widgets import format_unit_value
from progressbar.env import env_flag
from progressbar.terminal.base import clear_line
from progressbar.terminal.base import WindowsColors
from progressbar.utils import deltas_to_seconds


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_no_color_never_crashes(value):
    result = no_color(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_len_color_never_crashes(value):
    result = len_color(value)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(wrapper=st.one_of(st.none(), st.text(), st.tuples(st.one_of(st.none(), st.text()), st.one_of(st.none(), st.text()))))
def test_create_wrapper_never_crashes(wrapper):
    result = create_wrapper(wrapper)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(st.none(), st.integers(min_value=-10**18, max_value=10**18), st.floats(min_value=-1e308, max_value=1e308, allow_nan=False, allow_infinity=False)),
    unit=st.text(),
    unit_scale=st.booleans(),
)
def test_format_unit_value_never_crashes(value, unit, unit_scale):
    result = format_unit_value(value, unit=unit, unit_scale=unit_scale)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    name=st.text().filter(lambda s: "\x00" not in s),
    default=st.one_of(st.booleans(), st.none()),
)
def test_env_flag_never_crashes(name, default):
    result = env_flag(name, default)
    assert result is None or isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(n=st.integers(min_value=-1000000, max_value=1000000))
def test_clear_line_never_crashes(n):
    clear_line(n)


@settings(max_examples=300, deadline=None)
@given(rgb=st.tuples(st.integers(min_value=-1000000, max_value=1000000), st.integers(min_value=-1000000, max_value=1000000), st.integers(min_value=-1000000, max_value=1000000)))
def test_WindowsColors_never_crashes(rgb):
    WindowsColors.from_rgb(rgb)


@settings(max_examples=300, deadline=None)
@given(
    deltas=st.lists(st.one_of(st.none(), st.integers(min_value=-10**12, max_value=10**12), st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False), st.timedeltas()), min_size=0, max_size=5),
    default=st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False),
)
def test_deltas_to_seconds_never_crashes(deltas, default):
    result = deltas_to_seconds(*deltas, default=default)
    assert isinstance(result, float)
