import datetime

from hypothesis import given, settings
import hypothesis.strategies as st

from app.api.dependencies.articles import get_articles_filters
from app.models.domain.rwmodel import convert_field_to_camel_case
from app.services.articles import get_slug_for_article
from app.services.jwt import create_jwt_token
from app.services.jwt import get_username_from_token
from app.services.security import verify_password
from app.services.security import get_password_hash
from app.models.domain.rwmodel import convert_datetime_to_realworld


@settings(max_examples=300, deadline=None)
@given(
    tag=st.one_of(st.none(), st.text()),
    author=st.one_of(st.none(), st.text()),
    favorited=st.one_of(st.none(), st.text()),
    limit=st.integers(min_value=-1000000, max_value=1000000),
    offset=st.integers(min_value=-1000000, max_value=1000000),
)
def test_get_articles_filters_never_crashes(tag, author, favorited, limit, offset):
    get_articles_filters(tag=tag, author=author, favorited=favorited, limit=limit, offset=offset)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_convert_field_to_camel_case_never_crashes(s):
    convert_field_to_camel_case(s)


@settings(max_examples=300, deadline=None)
@given(title=st.text())
def test_get_slug_for_article_never_crashes(title):
    get_slug_for_article(title)


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_get_password_hash_never_crashes(password):
    get_password_hash(password)


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_verify_password_round_trips(password):
    hashed = get_password_hash(password)
    assert verify_password(password, hashed)


@settings(max_examples=300, deadline=None)
@given(
    content=st.dictionaries(st.text(), st.text()),
    secret_key=st.text(),
    expires_delta=st.timedeltas(),
)
def test_create_jwt_token_never_crashes(content, secret_key, expires_delta):
    create_jwt_token(jwt_content=content, secret_key=secret_key, expires_delta=expires_delta)


@settings(max_examples=300, deadline=None)
@given(
    username=st.text(min_size=1, max_size=100),
    secret_key=st.text(min_size=1, max_size=100),
    expires_delta=st.timedeltas(min_value=datetime.timedelta(seconds=1), max_value=datetime.timedelta(days=7)),
)
def test_get_username_from_token_round_trips(username, secret_key, expires_delta):
    token = create_jwt_token(
        jwt_content={"username": username},
        secret_key=secret_key,
        expires_delta=expires_delta,
    )
    assert get_username_from_token(token, secret_key) == username


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes())
def test_convert_datetime_to_realworld_never_crashes(dt):
    convert_datetime_to_realworld(dt)
