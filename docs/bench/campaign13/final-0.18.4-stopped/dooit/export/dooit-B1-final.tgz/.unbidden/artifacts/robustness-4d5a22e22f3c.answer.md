```python
# file: tests/test_unbidden_robustness.py
from dooit.backport.migrate_from_v2 import parse_recurrence
from dooit.backport.migrate_from_v2 import parse_due
from dooit.utils.date_parser import parse
from dooit.ui.widgets.inputs.model_inputs import Recurrence
from dooit.ui.api.api_components.keys import KeyManager
from dooit.utils.css_manager import CssManager
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_parse_recurrence_never_crashes(data):
    parse_recurrence(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_parse_due_never_crashes(data):
    parse_due(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_parse_never_crashes(data):
    parse(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_parse_recurrence_round_trips(data):
    Recurrence.parse_recurrence(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_register_key_never_crashes(data):
    obj = KeyManager()
    obj.register_key(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_get_keybinds_by_group_never_crashes(data):
    obj = KeyManager()
    obj.get_keybinds_by_group(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_write_never_crashes(data):
    obj = CssManager()
    obj.write(data)


@settings(max_examples=300, deadline=None)
@given(data=st.text())
def test_inject_css_never_crashes(data):
    obj = CssManager()
    obj.inject_css(data)
```
