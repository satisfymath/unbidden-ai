import datetime

import pytest
from hypothesis import given, settings, strategies as st

from marshmallow.utils import from_timestamp
from marshmallow.utils import from_timestamp_ms
from marshmallow.utils import timestamp
from marshmallow.utils import timestamp_ms
from marshmallow.utils import ensure_text_type
from marshmallow.utils import is_generator
from marshmallow.utils import is_iterable_but_not_string
from marshmallow.error_store import copy_containers


@settings(max_examples=300, deadline=None)
@given(val=st.one_of(st.text(), st.binary()))
def test_ensure_text_type_never_crashes(val):
    result = ensure_text_type(val)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    obj=st.one_of(
        st.none(),
        st.booleans(),
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
        st.text(),
        st.binary(),
        st.lists(st.integers()),
        st.dictionaries(st.text(), st.integers()),
        st.tuples(st.integers(), st.text()),
    )
)
def test_is_generator_never_crashes(obj):
    result = is_generator(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(
    obj=st.one_of(
        st.none(),
        st.booleans(),
        st.integers(),
        st.text(),
        st.binary(),
        st.lists(st.text()),
        st.tuples(st.integers()),
        st.dictionaries(st.text(), st.text()),
        st.sets(st.integers()),
    )
)
def test_is_iterable_but_not_string_never_crashes(obj):
    result = is_iterable_but_not_string(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(val=st.datetimes())
def test_timestamp_never_crashes(val):
    result = timestamp(val)
    assert isinstance(result, float)


@settings(max_examples=300, deadline=None)
@given(val=st.datetimes())
def test_timestamp_ms_never_crashes(val):
    result = timestamp_ms(val)
    assert isinstance(result, int)


@settings(max_examples=300, deadline=None)
@given(
    val=st.one_of(
        st.integers(min_value=-2000000000, max_value=2000000000),
        st.floats(
            min_value=-2000000000.0,
            max_value=2000000000.0,
            allow_nan=False,
            allow_infinity=False,
        ),
    )
)
def test_from_timestamp_never_crashes(val):
    result = from_timestamp(val)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(
    val=st.one_of(
        st.integers(min_value=-2000000000000, max_value=2000000000000),
        st.floats(
            min_value=-2000000000000.0,
            max_value=2000000000000.0,
            allow_nan=False,
            allow_infinity=False,
        ),
    )
)
def test_from_timestamp_ms_never_crashes(val):
    result = from_timestamp_ms(val)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(
    errors=st.recursive(
        st.one_of(st.text(), st.integers(), st.none()),
        lambda children: st.one_of(
            st.lists(children, max_size=3),
            st.dictionaries(st.text(), children, max_size=3),
        ),
        max_leaves=5,
    )
)
def test_copy_containers_never_crashes(errors):
    result = copy_containers(errors)
    assert result is not None
