```python
# file: tests/test_unbidden_robustness.py
import hypothesis.strategies as st
from hypothesis import given, settings

from mss.tools import to_png
from mss.tools import parse_edid
from mss.screenshot import ScreenShot
from mss.buffer import finalizing_buffer


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=16),
    height=st.integers(min_value=1, max_value=16),
    pixel=st.integers(min_value=0, max_value=255),
    level=st.integers(min_value=0, max_value=9),
)
def test_to_png_never_crashes(width, height, pixel, level):
    data = bytes([pixel]) * (width * height * 3)
    result = to_png(data, (width, height), level=level, output=None)
    assert isinstance(result, bytes)
    assert len(result) > 0


@settings(max_examples=300, deadline=None)
@given(data=st.binary(min_size=0, max_size=512))
def test_parse_edid_never_crashes(data):
    result = parse_edid(data)
    assert result is not None


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=16),
    height=st.integers(min_value=1, max_value=16),
    pixel=st.integers(min_value=0, max_value=255),
)
def test_from_size_never_crashes(width, height, pixel):
    data = bytes([pixel]) * (width * height * 4)
    shot = ScreenShot.from_size(data, width, height)
    assert shot.width == width
    assert shot.height == height


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=1, max_value=16),
    height=st.integers(min_value=1, max_value=16),
    payload=st.binary(min_size=0, max_size=1024),
)
def test_bgra_never_crashes(width, height, payload):
    n = width * height * 4
    raw = (payload * ((n // max(1, len(payload))) + 1))[:n] if payload else bytes(n)
    shot = ScreenShot.from_size(raw, width, height)
    val = shot.bgra
    if callable(val):
        val = val()
    assert isinstance(val, (bytes, bytearray, memoryview))


@settings(max_examples=300, deadline=None)
@given(data=st.binary(min_size=0, max_size=1024))
def test_finalizing_buffer_never_crashes(data):
    buf = finalizing_buffer(data, lambda *args: None)
    assert bytes(buf) == bytes(data)
```
