import hashlib

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from oauthlib.common import log_safe
from oauthlib.common import quote
from oauthlib.common import unquote
from oauthlib.common import urlencode
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_verifier
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_challenge
from oauthlib.oauth2.rfc6749.utils import list_to_scope
from oauthlib.oauth2.rfc6749.utils import scope_to_list


@settings(max_examples=300, deadline=None)
@given(s=st.text(), safe=st.one_of(st.just(b"/"), st.just(b""), st.binary(max_size=8)))
def test_quote_round_trips(s, safe):
    q = quote(s, safe=safe)
    assert isinstance(q, str)
    assert unquote(q) == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    result = unquote(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(scope=st.lists(st.text(), max_size=10))
def test_list_to_scope_never_crashes(scope):
    result = list_to_scope(scope)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_scope_to_list_round_trips(s):
    first = scope_to_list(s)
    assert isinstance(first, list)
    encoded = list_to_scope(first)
    assert isinstance(encoded, str)
    assert scope_to_list(encoded) == first


@settings(max_examples=300, deadline=None)
@given(v=st.text())
def test_is_valid_code_verifier_never_crashes(v):
    result = is_valid_code_verifier(v)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(challenge=st.text(), method=st.one_of(st.text(max_size=20), st.just("plain"), st.just("S256")))
def test_is_valid_code_challenge_never_crashes(challenge, method):
    result = is_valid_code_challenge(challenge, method)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(params=st.one_of(
    st.dictionaries(st.text(max_size=20), st.one_of(st.text(max_size=20), st.integers(min_value=-1000000, max_value=1000000))),
    st.lists(st.tuples(st.text(max_size=20), st.one_of(st.text(max_size=20), st.integers(min_value=-1000000, max_value=1000000))), max_size=10),
))
def test_urlencode_never_crashes(params):
    result = urlencode(params)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.text(), st.integers(min_value=-1000000000000, max_value=1000000000000), st.none(), st.binary(max_size=20)))
def test_log_safe_never_crashes(value):
    result = log_safe(value)
    assert isinstance(result, str)
