import urllib.parse
from rdflib.compat import cast_bytes
from rdflib.compat import decodeUnicodeEscape
from rdflib.contrib.graphdb.util import sanitize_filename
from rdflib.contrib.graphdb.util import extract_filename_from_content_disposition
from rdflib.plugins.parsers.ntriples import unquote
from rdflib.plugins.parsers.ntriples import uriquote
from rdflib.plugins.parsers.notation3 import splitFragP
from rdflib.plugins.parsers.notation3 import join
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(s=st.one_of(st.text(), st.binary()), enc=st.sampled_from(["utf-8", "ascii", "latin-1", "utf-16", "cp1252"]))
def test_cast_bytes_never_crashes(s, enc):
    try:
        result = cast_bytes(s, enc)
    except (UnicodeEncodeError, UnicodeDecodeError):
        return
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_decodeUnicodeEscape_never_crashes(s):
    result = decodeUnicodeEscape(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_sanitize_filename_never_crashes(s):
    result = sanitize_filename(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_extract_filename_from_content_disposition_never_crashes(s):
    result = extract_filename_from_content_disposition(s)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    result = unquote(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_uriquote_round_trips(s):
    quoted = uriquote(s)
    assert isinstance(quoted, str)
    assert unquote(quoted) == s


@settings(max_examples=300, deadline=None)
@given(uri=st.text(), punc=st.integers(min_value=-1000000, max_value=1000000))
def test_splitFragP_never_crashes(uri, punc):
    result = splitFragP(uri, punc)
    assert isinstance(result, tuple)


@settings(max_examples=300, deadline=None)
@given(here=st.text(), there=st.text())
def test_join_never_crashes(here, there):
    try:
        result = join(here, there)
    except (AssertionError, ValueError):
        return
    assert isinstance(result, str)
