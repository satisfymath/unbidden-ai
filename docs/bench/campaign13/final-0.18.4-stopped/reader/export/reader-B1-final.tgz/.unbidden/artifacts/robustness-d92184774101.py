from reader._app.legacy import highlighted
from reader._app.legacy import humanize_apnumber
from reader._app.legacy.api_thing import is_safe_url
from reader._plugins.legacy.enclosure_tags import enclosure_tags
from reader._plugins.legacy.share import percent_encode
from reader.plugins.entry_dedupe import strip_accents
from reader.plugins.entry_dedupe import tokenize
from reader.types import HighlightedString

from hypothesis import assume
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.integers())
def test_humanize_apnumber_never_crashes(value):
    humanize_apnumber(value)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_highlighted_never_crashes(s):
    highlighted(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_percent_encode_never_crashes(s):
    percent_encode(s, encoding="utf-8")


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_tokenize_never_crashes(s):
    tokenize(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_accents_never_crashes(s):
    strip_accents(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_enclosure_tags_never_crashes(s):
    enclosure_tags(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_is_safe_url_never_crashes(s):
    is_safe_url(s)


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text(), c=st.text())
def test_HighlightedString_round_trips(a, b, c):
    before = "\ue000"
    after = "\ue001"
    assume(before not in a and before not in b and before not in c)
    assume(after not in a and after not in b and after not in c)
    text = a + before + b + after + c
    hs = HighlightedString.extract(text, before, after)
    assert hs.apply(before, after) == text
