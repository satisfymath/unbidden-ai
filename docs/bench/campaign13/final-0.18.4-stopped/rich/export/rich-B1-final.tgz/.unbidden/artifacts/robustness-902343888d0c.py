import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from rich.markup import escape
from rich.control import strip_control_codes
from rich.control import escape_control_codes
from rich.cells import cell_len
from rich.cells import cached_cell_len
from rich.cells import split_graphemes
from rich.filesize import decimal
from rich.emoji import Emoji


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_escape_never_crashes(s):
    result = escape(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_control_codes_never_crashes(s):
    result = strip_control_codes(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_escape_control_codes_never_crashes(s):
    result = escape_control_codes(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cell_len_never_crashes(s):
    result = cell_len(s)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cached_cell_len_never_crashes(s):
    result = cached_cell_len(s)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_split_graphemes_never_crashes(s):
    result = split_graphemes(s)
    assert isinstance(result, list)


@settings(max_examples=300, deadline=None)
@given(n=st.integers(min_value=-10**18, max_value=10**18))
def test_decimal_never_crashes(n):
    result = decimal(n)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_Emoji_replace_never_crashes(s):
    result = Emoji.replace(s)
    assert isinstance(result, str)
