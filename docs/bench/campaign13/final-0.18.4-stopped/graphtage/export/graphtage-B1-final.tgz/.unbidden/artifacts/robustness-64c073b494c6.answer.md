```python
# file: tests/test_unbidden_robustness.py
import hypothesis.strategies as st
from hypothesis import given, settings
from graphtage.batch_distance import all_flat
from graphtage.batch_distance import all_pairs
from graphtage.batch_distance import cost
from graphtage.batch_distance import preprice_product
from graphtage.graphtage import string_edit_distance
from graphtage.json import build_tree
from graphtage.levenshtein import exact_string_distance
from graphtage.levenshtein import levenshtein_distance


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_levenshtein_distance_never_crashes(s, t):
    assert levenshtein_distance(s, t) >= 0


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_exact_string_distance_never_crashes(s, t):
    assert exact_string_distance(s, t) >= 0


@settings(max_examples=300, deadline=None)
@given(s1=st.text(), s2=st.text())
def test_string_edit_distance_never_crashes(s1, s2):
    assert string_edit_distance(s1, s2) >= 0


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text())
def test_cost_never_crashes(a, b):
    assert cost(a, b) >= 0


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text()), b=st.lists(st.text()))
def test_all_pairs_never_crashes(a, b):
    result = all_pairs(a, b)
    assert len(result) == len(a)


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text()), b=st.lists(st.text()))
def test_all_flat_never_crashes(a, b):
    result = all_flat(a, b)
    assert len(result) == min(len(a), len(b))


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text(max_size=20), max_size=10), b=st.lists(st.text(max_size=20), max_size=10))
def test_preprice_product_never_crashes(a, b):
    preprice_product(a, b)


json_scalars = st.one_of(
    st.integers(),
    st.floats(allow_nan=False, allow_infinity=False),
    st.booleans(),
    st.text(),
    st.binary(),
)
json_values = st.recursive(
    json_scalars,
    lambda children: st.one_of(
        st.lists(children),
        st.dictionaries(st.text(), children),
    ),
)


@settings(max_examples=300, deadline=None)
@given(obj=json_values)
def test_build_tree_never_crashes(obj):
    node = build_tree(obj)
    assert node is not None
```
