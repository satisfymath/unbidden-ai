```python
# file: tests/test_unbidden_robustness.py
import datetime as dt

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from humanize.filesize import naturalsize
from humanize.number import ordinal
from humanize.number import intcomma
from humanize.number import intword
from humanize.number import apnumber
from humanize.number import fractional
from humanize.lists import natural_list
from humanize.time import precisedelta


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**12, max_value=10**30),
        st.floats(min_value=-1e12, max_value=1e30, allow_nan=False, allow_infinity=False),
        st.sampled_from(["0", "1", "1000", "1.5", "1e6", "12345678901234567890"]),
    ),
    binary=st.booleans(),
    gnu=st.booleans(),
)
def test_naturalsize_never_crashes(value, binary, gnu):
    naturalsize(value, binary=binary, gnu=gnu)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**12, max_value=10**12),
        st.sampled_from(["0", "1", "2", "3", "11", "12", "13", "101", "-5", "1000000"]),
    ),
    gender=st.sampled_from(["male", "female", "neuter"]),
)
def test_ordinal_never_crashes(value, gender):
    ordinal(value, gender=gender)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e15, max_value=1e15, allow_nan=False, allow_infinity=False),
        st.sampled_from(["0", "1", "-1234", "1234567", "1234.5678", "0.0", ""]),
    ),
    ndigits=st.one_of(st.none(), st.integers(min_value=-5, max_value=10)),
)
def test_intcomma_never_crashes(value, ndigits):
    # empty string documents to empty handling path; avoid it if it raises by filtering
    assume_value = value
    if assume_value == "":
        pytest.skip("empty string is out of documented numeric domain")
    intcomma(assume_value, ndigits=ndigits)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e30, max_value=1e30, allow_nan=False, allow_infinity=False),
        st.sampled_from(["0", "1", "1000", "1000000", "1234567890", "-5000", "1.5"]),
    )
)
def test_intword_never_crashes(value):
    intword(value)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.text(), st.integers(min_value=-10**12, max_value=10**12)))
def test_apnumber_never_crashes(value):
    apnumber(value)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
        st.sampled_from(["0", "1", "0.5", "1.5", "2.25", "-3.75", "10"]),
    )
)
def test_fractional_never_crashes(value):
    fractional(value)


@settings(max_examples=300, deadline=None)
@given(items=st.lists(st.text(), max_size=10))
def test_natural_list_never_crashes(items):
    natural_list(items)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.none(),
        st.floats(min_value=0, max_value=1e12, allow_nan=False, allow_infinity=False),
        st.integers(min_value=0, max_value=10**12),
        st.timedeltas(min_value=dt.timedelta(0), max_value=dt.timedelta(days=365 * 200)),
    ),
    minimum_unit=st.sampled_from(
        ["years", "months", "days", "hours", "minutes", "seconds", "microseconds"]
    ),
    suppress=st.lists(
        st.sampled_from(["years", "months", "days", "hours", "minutes", "seconds", "microseconds"]),
        max_size=3,
        unique=True,
    ),
)
def test_precisedelta_never_crashes(value, minimum_unit, suppress):
    precisedelta(value, minimum_unit=minimum_unit, suppress=suppress)
```
