import hashlib
from jwt.algorithms import HMACAlgorithm
from jwt.algorithms import NoneAlgorithm
from jwt.jwk_set_cache import JWKSetCache
from jwt.utils import base64url_decode
from jwt.utils import base64url_encode
from jwt.utils import bytes_to_number
from jwt.utils import force_bytes
from jwt.utils import from_base64url_uint
from jwt.utils import to_base64url_uint
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(v=st.text())
def test_force_bytes_never_crashes(v):
    force_bytes(v)


@settings(max_examples=300, deadline=None)
@given(v=st.binary())
def test_base64url_encode_never_crashes(v):
    base64url_encode(v)


@settings(max_examples=300, deadline=None)
@given(v=st.binary())
def test_base64url_encode_round_trips(v):
    assert base64url_decode(base64url_encode(v)) == v


@settings(max_examples=300, deadline=None)
@given(v=st.binary())
def test_bytes_to_number_never_crashes(v):
    bytes_to_number(v)


@settings(max_examples=300, deadline=None)
@given(v=st.integers(min_value=0, max_value=2**4096))
def test_to_base64url_uint_round_trips(v):
    assert from_base64url_uint(to_base64url_uint(v)) == v


@settings(max_examples=300, deadline=None)
@given(v=st.one_of(st.text(), st.binary()))
def test_prepare_key_never_crashes(v):
    HMACAlgorithm(hashlib.sha256).prepare_key(v)


@settings(max_examples=300, deadline=None)
@given(v=st.one_of(st.text(), st.none()))
def test_prepare_key_never_crashes_2(v):
    NoneAlgorithm().prepare_key(v)


@settings(max_examples=300, deadline=None)
@given(v=st.one_of(st.none(), st.dictionaries(st.text(), st.one_of(st.text(), st.integers(), st.none()))))
def test_put_never_crashes(v):
    JWKSetCache(60).put(v)
