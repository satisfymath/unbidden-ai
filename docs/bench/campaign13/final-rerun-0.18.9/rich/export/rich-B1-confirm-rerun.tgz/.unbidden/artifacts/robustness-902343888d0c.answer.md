```python
# file: tests/test_unbidden_robustness.py
from rich.cells import cached_cell_len
from rich.cells import cell_len
from rich.control import escape_control_codes
from rich.control import strip_control_codes
from rich.emoji import Emoji
from rich.filesize import decimal
from rich.markup import escape
from rich.markup import render
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_escape_round_trips(text):
    escaped = escape(text)
    rendered = render(escaped, emoji=False)
    assert rendered.plain == text


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_render_never_crashes(text):
    result = render(text, emoji=False)
    assert isinstance(result.plain, str)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_strip_control_codes_never_crashes(text):
    result = strip_control_codes(text)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_escape_control_codes_never_crashes(text):
    result = escape_control_codes(text)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_cell_len_never_crashes(text):
    result = cell_len(text)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_cached_cell_len_never_crashes(text):
    result = cached_cell_len(text)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_replace_never_crashes(text):
    result = Emoji.replace(text)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    size=st.integers(min_value=0, max_value=10**30),
    precision=st.one_of(st.none(), st.integers(min_value=0, max_value=10)),
    separator=st.text(max_size=5),
)
def test_decimal_never_crashes(size, precision, separator):
    result = decimal(size, precision=precision, separator=separator)
    assert isinstance(result, str)
```
