import pytest
from hypothesis import given, settings, strategies as st
from aegra_api.settings import parse_lower
from aegra_api.settings import parse_upper
from aegra_api.services.event_streaming.channels import is_supported_channel
from aegra_api.services.event_streaming.normalizers import normalize_state_payload
from aegra_api.utils.sse_utils import generate_event_id
from aegra_api.utils.sse_utils import extract_event_sequence
from aegra_api.services.run_waiters import error_envelope
from aegra_api.utils.run_utils import strip_pinned_config_keys
from aegra_api.models.search_limit import resolve_search_limit

json_atoms = st.one_of(st.none(), st.booleans(), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.text())
json_values = st.recursive(json_atoms, lambda c: st.one_of(st.lists(c), st.dictionaries(st.text(), c)))


@settings(max_examples=300, deadline=None)
@given(st.text())
def test_parse_lower_never_crashes(s):
    parse_lower(s)


@settings(max_examples=300, deadline=None)
@given(st.text())
def test_parse_upper_never_crashes(s):
    parse_upper(s)


@settings(max_examples=300, deadline=None)
@given(st.text())
def test_is_supported_channel_never_crashes(channel):
    result = is_supported_channel(channel)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(json_values)
def test_normalize_state_payload_never_crashes(value):
    normalize_state_payload(value)


@settings(max_examples=300, deadline=None)
@given(run_id=st.from_regex(r"[A-Za-z0-9-]{1,32}", fullmatch=True), sequence=st.integers(min_value=-1000000, max_value=1000000))
def test_generate_event_id_round_trips(run_id, sequence):
    event_id = generate_event_id(run_id, sequence)
    assert isinstance(event_id, str)
    assert extract_event_sequence(event_id) == sequence


@settings(max_examples=300, deadline=None)
@given(st.text(), st.text())
def test_error_envelope_never_crashes(error, message):
    body = error_envelope(error, message)
    assert isinstance(body, dict)


@settings(max_examples=300, deadline=None)
@given(st.dictionaries(st.text(), json_values))
def test_strip_pinned_config_keys_never_crashes(client_config):
    result = strip_pinned_config_keys(client_config)
    assert isinstance(result, dict)


@settings(max_examples=300, deadline=None)
@given(st.one_of(st.none(), st.integers()))
def test_resolve_search_limit_never_crashes(value):
    resolve_search_limit(value)
