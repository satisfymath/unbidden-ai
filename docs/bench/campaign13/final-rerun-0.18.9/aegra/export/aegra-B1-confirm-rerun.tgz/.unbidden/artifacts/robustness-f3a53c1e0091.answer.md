```python
# file: tests/test_unbidden_robustness.py
import string
from hypothesis import assume, given, settings, strategies as st
from aegra_api.settings import parse_lower
from aegra_api.settings import parse_upper
from aegra_api.services.event_streaming.channels import is_supported_channel
from aegra_api.services.event_streaming.normalizers import lifecycle_status
from aegra_api.services.event_streaming.normalizers import normalize_state_payload
from aegra_api.utils.sse_utils import generate_event_id
from aegra_api.utils.sse_utils import extract_event_sequence
from aegra_api.core.auth_registry import is_self_dispatching
from aegra_api.observability.span_enrichment import merge_run_metadata


@settings(max_examples=300, deadline=None)
@given(v=st.text())
def test_parse_lower_never_crashes(v):
    assert parse_lower(v) == v.strip().lower()


@settings(max_examples=300, deadline=None)
@given(v=st.text())
def test_parse_upper_never_crashes(v):
    assert parse_upper(v) == v.strip().upper()


@settings(max_examples=300, deadline=None)
@given(channel=st.text())
def test_is_supported_channel_never_crashes(channel):
    result = is_supported_channel(channel)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(run_status=st.text())
def test_lifecycle_status_never_crashes(run_status):
    result = lifecycle_status(run_status)
    assert isinstance(result, str)


json_like = st.recursive(
    st.none() | st.booleans() | st.integers() | st.floats(allow_nan=False, allow_infinity=False) | st.text(),
    lambda children: st.lists(children) | st.dictionaries(st.text(), children),
)


@settings(max_examples=300, deadline=None)
@given(value=json_like)
def test_normalize_state_payload_never_crashes(value):
    normalize_state_payload(value)


@settings(max_examples=300, deadline=None)
@given(run_id=st.text(), sequence=st.integers(min_value=0, max_value=10**18))
def test_generate_event_id_round_trips(run_id, sequence):
    assume("_event_" not in run_id)
    eid = generate_event_id(run_id, sequence)
    assert isinstance(eid, str)
    assert extract_event_sequence(eid) == sequence


@settings(max_examples=300, deadline=None)
@given(method=st.text(), path=st.text())
def test_is_self_dispatching_never_crashes(method, path):
    result = is_self_dispatching(method, path)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(
    extra=st.one_of(st.none(), st.dictionaries(st.text(), json_like)),
    system=st.dictionaries(st.text(), st.one_of(st.text(), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.booleans())),
)
def test_merge_run_metadata_never_crashes(extra, system):
    result = merge_run_metadata(extra, system)
    assert isinstance(result, dict)
    for k, v in system.items():
        assert result[k] == v
```
