```python
# file: tests/test_unbidden_robustness.py
from mss.tools import to_png
from mss.tools import parse_edid
from mss.screenshot import ScreenShot
from mss.models import Monitor
from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=0, max_value=32),
    height=st.integers(min_value=0, max_value=32),
    fill=st.integers(min_value=0, max_value=255),
    level=st.integers(min_value=0, max_value=9),
)
def test_to_png_never_crashes(width, height, fill, level):
    data = bytes([fill]) * (width * height * 4)
    result = to_png(data, (width, height), level=level)
    assert isinstance(result, bytes)
    if width > 0 and height > 0:
        assert result[:8] == b"\x89PNG\r\n\x1a\n"


@settings(max_examples=300, deadline=None)
@given(payload=st.text())
def test_parse_edid_never_crashes(payload):
    data = payload.encode("utf-8", errors="ignore")
    parse_edid(data)


@settings(max_examples=300, deadline=None)
@given(payload=st.binary(max_size=1024))
def test_parse_edid_bytes_never_crashes(payload):
    parse_edid(payload)


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=0, max_value=64),
    height=st.integers(min_value=0, max_value=64),
    fill=st.integers(min_value=0, max_value=255),
)
def test_from_size_never_crashes(width, height, fill):
    data = bytes([fill]) * (width * height * 4)
    shot = ScreenShot.from_size(data, width, height)
    assert shot.width == width
    assert shot.height == height


@settings(max_examples=300, deadline=None)
@given(
    width=st.integers(min_value=0, max_value=32),
    height=st.integers(min_value=0, max_value=32),
    fill=st.integers(min_value=0, max_value=255),
)
def test_bgra_never_crashes(width, height, fill):
    data = bytes([fill]) * (width * height * 4)
    shot = ScreenShot.from_size(data, width, height)
    result = shot.bgra
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(
    left=st.integers(min_value=-10000, max_value=10000),
    top=st.integers(min_value=-10000, max_value=10000),
    width=st.integers(min_value=0, max_value=10000),
    height=st.integers(min_value=0, max_value=10000),
)
def test_as_region_never_crashes(left, top, width, height):
    mon = Monitor(left=left, top=top, width=width, height=height)
    region = mon.as_region()
    assert region["left"] == left
    assert region["top"] == top
    assert region["width"] == width
    assert region["height"] == height
```
