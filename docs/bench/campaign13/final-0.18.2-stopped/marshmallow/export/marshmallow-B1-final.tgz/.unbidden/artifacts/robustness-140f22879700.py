import datetime

from hypothesis import given, settings
import hypothesis.strategies as st

from marshmallow.utils import ensure_text_type
from marshmallow.utils import from_timestamp
from marshmallow.utils import from_timestamp_ms
from marshmallow.utils import timestamp
from marshmallow.utils import timestamp_ms
from marshmallow.utils import is_generator
from marshmallow.utils import is_iterable_but_not_string
from marshmallow.orderedset import OrderedSet


@settings(max_examples=300, deadline=None)
@given(val=st.one_of(st.text(), st.binary()))
def test_ensure_text_type_never_crashes(val):
    result = ensure_text_type(val)
    assert isinstance(result, str)
    if isinstance(val, str):
        assert result == val


@settings(max_examples=300, deadline=None)
@given(value=st.floats(min_value=-2000000000.0, max_value=2000000000.0, allow_nan=False, allow_infinity=False))
def test_from_timestamp_never_crashes(value):
    result = from_timestamp(value)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.integers(min_value=-2000000000000, max_value=2000000000000), st.floats(min_value=-2000000000000.0, max_value=2000000000000.0, allow_nan=False, allow_infinity=False)))
def test_from_timestamp_ms_never_crashes(value):
    result = from_timestamp_ms(value)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(value=st.datetimes(min_value=datetime.datetime(1970, 1, 1), max_value=datetime.datetime(2030, 1, 1)))
def test_timestamp_round_trips(value):
    ts = timestamp(value)
    assert isinstance(ts, float)
    back = from_timestamp(ts)
    assert isinstance(back, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(value=st.datetimes(min_value=datetime.datetime(1970, 1, 1), max_value=datetime.datetime(2030, 1, 1)))
def test_timestamp_ms_round_trips(value):
    ts = timestamp_ms(value)
    back = from_timestamp_ms(ts)
    assert isinstance(back, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.text(), st.binary(), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.none(), st.lists(st.integers()), st.dictionaries(st.text(), st.integers()), st.tuples(st.integers())))
def test_is_generator_never_crashes(obj):
    result = is_generator(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.text(), st.binary(), st.bytearray(st.binary()), st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.none(), st.booleans(), st.lists(st.one_of(st.text(), st.integers())), st.tuples(st.integers()), st.dictionaries(st.text(), st.integers()), st.sets(st.integers())))
def test_is_iterable_but_not_string_never_crashes(obj):
    result = is_iterable_but_not_string(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.integers(), st.binary(), st.booleans(), st.none()))
def test_add_never_crashes(key):
    s = OrderedSet()
    s.add(key)
    assert key in s
