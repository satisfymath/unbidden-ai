import hashlib
from hypothesis import given, settings
import hypothesis.strategies as st
from jwt.algorithms import Algorithm
from jwt.algorithms import HMACAlgorithm
from jwt.algorithms import NoneAlgorithm
from jwt.jwk_set_cache import JWKSetCache
from jwt.utils import force_bytes
from jwt.utils import base64url_encode
from jwt.utils import base64url_decode
from jwt.utils import to_base64url_uint
from jwt.utils import from_base64url_uint
from jwt.utils import bytes_to_number


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.text(), st.binary()))
def test_force_bytes_never_crashes(value):
    assert force_bytes(value) is not None


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_encode_round_trips(data):
    assert base64url_decode(base64url_encode(data)) == data


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_bytes_to_number_never_crashes(data):
    assert isinstance(bytes_to_number(data), int)


@settings(max_examples=300, deadline=None)
@given(val=st.integers(min_value=0, max_value=2**4096 - 1))
def test_to_base64url_uint_round_trips(val):
    assert from_base64url_uint(to_base64url_uint(val)) == val


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.binary()))
def test_prepare_key_never_crashes(key):
    assert HMACAlgorithm.prepare_key(HMACAlgorithm("HS256"), key) is not None


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.none(), st.text()))
def test_prepare_key_never_crashes_2(key):
    assert NoneAlgorithm.prepare_key(NoneAlgorithm(), key) is None or True


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_compute_hash_digest_never_crashes(data):
    assert Algorithm.compute_hash_digest(Algorithm(hashlib.sha256), data) is not None


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.none(), st.dictionaries(st.text(), st.one_of(st.text(), st.integers(), st.none()))))
def test_put_never_crashes(value):
    JWKSetCache().put(value)
