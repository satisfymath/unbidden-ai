from humanize.filesize import naturalsize
from humanize.number import ordinal
from humanize.number import intcomma
from humanize.number import intword
from humanize.number import fractional
from humanize.time import naturaldelta
from humanize.time import precisedelta
from humanize.lists import natural_list
import datetime as dt
from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e30, max_value=1e30, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**30, max_value=10**30).map(str),
    ),
    binary=st.booleans(),
    gnu=st.booleans(),
)
def test_naturalsize_never_crashes(value, binary, gnu):
    result = naturalsize(value, binary=binary, gnu=gnu)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**18, max_value=10**18),
        st.integers(min_value=-10**18, max_value=10**18).map(str),
    )
)
def test_ordinal_never_crashes(value):
    result = ordinal(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e15, max_value=1e15, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**30, max_value=10**30).map(str),
    )
)
def test_intcomma_never_crashes(value):
    result = intcomma(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e30, max_value=1e30, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**30, max_value=10**30).map(str),
    )
)
def test_intword_never_crashes(value):
    result = intword(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**12, max_value=10**12).map(str),
    )
)
def test_fractional_never_crashes(value):
    result = fractional(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**12, max_value=10**12),
        st.timedeltas(min_value=dt.timedelta(days=-100000), max_value=dt.timedelta(days=100000)),
    ),
    minimum_unit=st.sampled_from(["seconds", "minutes", "hours", "days", "months", "years"]),
)
def test_naturaldelta_never_crashes(value, minimum_unit):
    result = naturaldelta(value, minimum_unit=minimum_unit)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.none(),
        st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**12, max_value=10**12),
        st.timedeltas(min_value=dt.timedelta(days=-100000), max_value=dt.timedelta(days=100000)),
    ),
    minimum_unit=st.sampled_from(["seconds", "minutes", "hours", "days", "months", "years"]),
)
def test_precisedelta_never_crashes(value, minimum_unit):
    result = precisedelta(value, minimum_unit=minimum_unit)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(items=st.lists(st.text(), max_size=10))
def test_natural_list_never_crashes(items):
    result = natural_list(items)
    assert isinstance(result, str)
