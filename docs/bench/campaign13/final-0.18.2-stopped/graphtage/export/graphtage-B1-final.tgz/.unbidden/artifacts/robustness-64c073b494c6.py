from graphtage.batch_distance import all_flat
from graphtage.batch_distance import all_pairs
from graphtage.batch_distance import cost
from graphtage.git import mime_options
from graphtage.git import split_options
from graphtage.graphtage import string_edit_distance
from graphtage.levenshtein import exact_string_distance
from graphtage.levenshtein import levenshtein_distance
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_levenshtein_distance_never_crashes(s, t):
    levenshtein_distance(s, t)


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_exact_string_distance_never_crashes(s, t):
    exact_string_distance(s, t)


@settings(max_examples=300, deadline=None)
@given(s1=st.text(), s2=st.text())
def test_string_edit_distance_never_crashes(s1, s2):
    string_edit_distance(s1, s2)


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text())
def test_cost_never_crashes(a, b):
    cost(a, b)


@settings(max_examples=300, deadline=None)
@given(
    from_strings=st.lists(st.text(), max_size=5),
    to_strings=st.lists(st.text(), max_size=5),
)
def test_all_pairs_never_crashes(from_strings, to_strings):
    all_pairs(from_strings, to_strings)


@settings(max_examples=300, deadline=None)
@given(
    a=st.lists(st.text(), max_size=5),
    b=st.lists(st.text(), max_size=5),
)
def test_all_flat_never_crashes(a, b):
    all_flat(a, b)


@settings(max_examples=300, deadline=None)
@given(argv=st.lists(st.text(), max_size=10))
def test_split_options_never_crashes(argv):
    split_options(argv)


@settings(max_examples=300, deadline=None)
@given(path=st.text(), forwarded=st.lists(st.text(), max_size=5))
def test_mime_options_never_crashes(path, forwarded):
    mime_options(path, forwarded)
