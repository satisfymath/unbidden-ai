from hypothesis import given, settings, strategies as st
from oauthlib.common import quote
from oauthlib.common import unquote
from oauthlib.common import generate_token
from oauthlib.oauth1.rfc5849.signature import signature_base_string
from oauthlib.oauth1.rfc5849.signature import base_string_uri
from oauthlib.oauth2.rfc6749.utils import list_to_scope
from oauthlib.oauth2.rfc6749.utils import scope_to_list
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_verifier
from oauthlib.oauth2.rfc6749.grant_types.authorization_code import is_valid_code_challenge


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_quote_round_trips(s):
    assert unquote(quote(s)) == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    unquote(s)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=-100, max_value=500), chars=st.text(min_size=1, max_size=50))
def test_generate_token_never_crashes(length, chars):
    generate_token(length=length, chars=chars)


@settings(max_examples=300, deadline=None)
@given(
    http_method=st.text(),
    base_str_uri=st.text(),
    normalized_encoded_request_parameters=st.text(),
)
def test_signature_base_string_never_crashes(http_method, base_str_uri, normalized_encoded_request_parameters):
    signature_base_string(http_method, base_str_uri, normalized_encoded_request_parameters)


@settings(max_examples=300, deadline=None)
@given(uri=st.text(), host=st.one_of(st.none(), st.text()))
def test_base_string_uri_never_crashes(uri, host):
    if host is None:
        base_string_uri(uri)
    else:
        base_string_uri(uri, host)


@settings(max_examples=300, deadline=None)
@given(scope=st.lists(st.text(), max_size=10))
def test_list_to_scope_never_crashes(scope):
    list_to_scope(scope)


@settings(max_examples=300, deadline=None)
@given(scope=st.one_of(st.none(), st.text()))
def test_scope_to_list_never_crashes(scope):
    scope_to_list(scope)


@settings(max_examples=300, deadline=None)
@given(verifier=st.text())
def test_is_valid_code_verifier_never_crashes(verifier):
    is_valid_code_verifier(verifier)


@settings(max_examples=300, deadline=None)
@given(
    challenge=st.text(),
    method=st.one_of(st.text(), st.sampled_from(["plain", "S256"])),
)
def test_is_valid_code_challenge_never_crashes(challenge, method):
    is_valid_code_challenge(challenge, method)
