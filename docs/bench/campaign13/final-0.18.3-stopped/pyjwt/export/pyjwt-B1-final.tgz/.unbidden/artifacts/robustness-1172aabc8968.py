from jwt.algorithms import HMACAlgorithm
from jwt.algorithms import NoneAlgorithm
from jwt.utils import force_bytes
from jwt.utils import base64url_decode
from jwt.utils import base64url_encode
from jwt.utils import from_base64url_uint
from jwt.utils import to_base64url_uint
from jwt.utils import bytes_to_number
import hashlib
from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.text(), st.binary()))
def test_force_bytes_never_crashes(data):
    result = force_bytes(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_encode_never_crashes(data):
    result = base64url_encode(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_decode_round_trips(data):
    encoded = base64url_encode(data)
    assert base64url_decode(encoded) == data


@settings(max_examples=300, deadline=None)
@given(val=st.integers(min_value=0, max_value=2**4096))
def test_to_base64url_uint_round_trips(val):
    encoded = to_base64url_uint(val)
    assert from_base64url_uint(encoded) == val


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_bytes_to_number_never_crashes(data):
    result = bytes_to_number(data)
    assert isinstance(result, int)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.text(), st.binary()))
def test_prepare_key_never_crashes(data):
    obj = HMACAlgorithm(HMACAlgorithm.SHA256)
    result = obj.prepare_key(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.text(), st.none()))
def test_prepare_key_never_crashes_2(data):
    obj = NoneAlgorithm()
    result = obj.prepare_key(data)
    assert result is None or isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.text(), st.binary(min_size=1, max_size=64)))
def test_to_jwk_never_crashes(data):
    result = HMACAlgorithm.to_jwk(data, as_dict=True)
    assert isinstance(result, dict)
