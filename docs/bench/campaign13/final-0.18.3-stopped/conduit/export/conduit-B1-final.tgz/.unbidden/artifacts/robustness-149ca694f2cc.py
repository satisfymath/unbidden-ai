from datetime import datetime, timedelta

from hypothesis import given, settings
import hypothesis.strategies as st

from app.api.dependencies.articles import get_articles_filters
from app.models.common import DateTimeModelMixin
from app.models.domain.rwmodel import convert_field_to_camel_case
from app.models.domain.rwmodel import convert_datetime_to_realworld
from app.services.articles import get_slug_for_article
from app.services.jwt import create_jwt_token
from app.services.jwt import get_username_from_token
from app.services.security import verify_password
from app.services.security import get_password_hash


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_convert_field_to_camel_case_never_crashes(s):
    convert_field_to_camel_case(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_get_slug_for_article_never_crashes(s):
    get_slug_for_article(s)


@settings(max_examples=300, deadline=None)
@given(p=st.text())
def test_get_password_hash_round_trips(p):
    hashed = get_password_hash(p)
    assert verify_password(p, hashed)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes())
def test_convert_datetime_to_realworld_never_crashes(dt):
    convert_datetime_to_realworld(dt)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes())
def test_default_datetime_never_crashes(dt):
    DateTimeModelMixin.default_datetime(dt)


@settings(max_examples=300, deadline=None)
@given(
    content=st.dictionaries(st.text(), st.text()),
    secret=st.text(),
    delta=st.timedeltas(),
)
def test_create_jwt_token_never_crashes(content, secret, delta):
    create_jwt_token(jwt_content=content, secret_key=secret, expires_delta=delta)


@settings(max_examples=300, deadline=None)
@given(
    tag=st.one_of(st.none(), st.text()),
    author=st.one_of(st.none(), st.text()),
    favorited=st.one_of(st.none(), st.text()),
    limit=st.integers(),
    offset=st.integers(),
)
def test_get_articles_filters_never_crashes(tag, author, favorited, limit, offset):
    get_articles_filters(tag=tag, author=author, favorited=favorited, limit=limit, offset=offset)


@settings(max_examples=300, deadline=None)
@given(username=st.text(), secret=st.text(), delta=st.timedeltas())
def test_create_jwt_token_round_trips(username, secret, delta):
    token = create_jwt_token(jwt_content={"username": username}, secret_key=secret, expires_delta=delta)
    assert get_username_from_token(token, secret) == username
