import datetime

import hypothesis.strategies as st
from hypothesis import given, settings

from progressbar.utils import no_color
from progressbar.utils import len_color
from progressbar.widgets import format_unit_value
from progressbar.utils import deltas_to_seconds
from progressbar.terminal.base import clear_line
from progressbar.terminal.base import WindowsColors
from progressbar.widgets import string_or_lambda
from progressbar.widgets import create_wrapper


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_no_color_never_crashes(value):
    result = no_color(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_len_color_never_crashes(value):
    result = len_color(value)
    assert isinstance(result, int)
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.none(),
        st.integers(min_value=-(10 ** 12), max_value=10 ** 12),
        st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False),
    ),
    unit=st.text(),
    unit_scale=st.booleans(),
)
def test_format_unit_value_never_crashes(value, unit, unit_scale):
    result = format_unit_value(value, unit=unit, unit_scale=unit_scale)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    deltas=st.lists(
        st.one_of(
            st.none(),
            st.integers(min_value=-(10 ** 12), max_value=10 ** 12),
            st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False),
            st.timedeltas(),
        ),
        max_size=5,
    ),
    default=st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
)
def test_deltas_to_seconds_never_crashes(deltas, default):
    result = deltas_to_seconds(*deltas, default=default)
    assert isinstance(result, (int, float))


@settings(max_examples=300, deadline=None)
@given(n=st.integers(min_value=-(10 ** 9), max_value=10 ** 9))
def test_clear_line_never_crashes(n):
    clear_line(n)


@settings(max_examples=300, deadline=None)
@given(
    rgb=st.tuples(
        st.integers(min_value=-1000, max_value=2000),
        st.integers(min_value=-1000, max_value=2000),
        st.integers(min_value=-1000, max_value=2000),
    )
)
def test_from_rgb_never_crashes(rgb):
    WindowsColors.from_rgb(rgb)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_string_or_lambda_never_crashes(value):
    result = string_or_lambda(value)
    assert callable(result)


@settings(max_examples=300, deadline=None)
@given(
    wrapper_arg=st.one_of(
        st.none(),
        st.text(),
        st.tuples(
            st.one_of(st.none(), st.text()),
            st.one_of(st.none(), st.text()),
        ),
    )
)
def test_create_wrapper_never_crashes(wrapper_arg):
    result = create_wrapper(wrapper_arg)
    assert isinstance(result, str)
