from hypothesis import given, settings, strategies as st
from oauthlib.common import log_safe
from oauthlib.common import quote
from oauthlib.common import unquote
from oauthlib.common import generate_token
from oauthlib.common import generate_client_id
from oauthlib.oauth1.rfc5849.signature import signature_base_string
from oauthlib.oauth1.rfc5849.signature import base_string_uri
from oauthlib.oauth2.rfc6749.utils import list_to_scope
from oauthlib.oauth2.rfc6749.utils import scope_to_list


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_quote_round_trips(s):
    assert unquote(quote(s)) == s


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_log_safe_never_crashes(value):
    log_safe(value)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=100))
def test_generate_token_never_crashes(length):
    generate_token(length=length)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=100))
def test_generate_client_id_never_crashes(length):
    generate_client_id(length=length)


@settings(max_examples=300, deadline=None)
@given(
    http_method=st.text(),
    base_str_uri=st.text(),
    normalized_encoded_request_parameters=st.text(),
)
def test_signature_base_string_never_crashes(http_method, base_str_uri, normalized_encoded_request_parameters):
    signature_base_string(http_method, base_str_uri, normalized_encoded_request_parameters)


@settings(max_examples=300, deadline=None)
@given(uri=st.text(), host=st.one_of(st.none(), st.text()))
def test_base_string_uri_never_crashes(uri, host):
    try:
        base_string_uri(uri, host)
    except ValueError:
        pass


@settings(max_examples=300, deadline=None)
@given(scope=st.lists(st.text(alphabet="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-", min_size=1), min_size=1, max_size=5))
def test_list_to_scope_round_trips(scope):
    assert scope_to_list(list_to_scope(scope)) == scope


@settings(max_examples=300, deadline=None)
@given(scope=st.text())
def test_scope_to_list_never_crashes(scope):
    scope_to_list(scope)
