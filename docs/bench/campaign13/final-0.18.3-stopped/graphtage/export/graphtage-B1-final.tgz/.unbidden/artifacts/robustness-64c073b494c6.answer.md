```python
# file: tests/test_unbidden_robustness.py
from graphtage.batch_distance import all_flat
from graphtage.batch_distance import all_pairs
from graphtage.batch_distance import cost
from graphtage.batch_distance import preprice_product
from graphtage.git import split_options
from graphtage.graphtage import string_edit_distance
from graphtage.levenshtein import exact_string_distance
from graphtage.levenshtein import levenshtein_distance
from hypothesis import given
from hypothesis import settings
from hypothesis import strategies as st


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_levenshtein_distance_never_crashes(s, t):
    levenshtein_distance(s, t)


@settings(max_examples=300, deadline=None)
@given(s=st.text(), t=st.text())
def test_exact_string_distance_never_crashes(s, t):
    exact_string_distance(s, t)


@settings(max_examples=300, deadline=None)
@given(s1=st.text(), s2=st.text())
def test_string_edit_distance_never_crashes(s1, s2):
    string_edit_distance(s1, s2)


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text())
def test_cost_never_crashes(a, b):
    cost(a, b)


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text()), b=st.lists(st.text()))
def test_all_pairs_never_crashes(a, b):
    all_pairs(a, b)


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text()), b=st.lists(st.text()))
def test_all_flat_never_crashes(a, b):
    all_flat(a, b)


@settings(max_examples=300, deadline=None)
@given(a=st.lists(st.text()), b=st.lists(st.text()))
def test_preprice_product_never_crashes(a, b):
    preprice_product(a, b)


@settings(max_examples=300, deadline=None)
@given(argv=st.lists(st.text()))
def test_split_options_never_crashes(argv):
    split_options(argv)
```