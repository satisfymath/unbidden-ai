import struct

from hypothesis import given, settings, strategies as st
from mss.models import Monitor
from mss.screenshot import ScreenShot
from mss.tools import parse_edid
from mss.tools import to_png


@settings(max_examples=300, deadline=None)
@given(data=st.data())
def test_to_png_never_crashes(data):
    w = data.draw(st.integers(min_value=1, max_value=32))
    h = data.draw(st.integers(min_value=1, max_value=32))
    n = w * h * 4
    raw = data.draw(st.binary(min_size=n, max_size=n))
    level = data.draw(st.integers(min_value=0, max_value=9))
    out = to_png(raw, (w, h), level=level)
    assert isinstance(out, bytes)
    assert len(out) > 0


@settings(max_examples=300, deadline=None)
@given(data=st.data())
def test_to_png_memoryview_round_trips(data):
    w = data.draw(st.integers(min_value=1, max_value=32))
    h = data.draw(st.integers(min_value=1, max_value=32))
    n = w * h * 4
    raw = data.draw(st.binary(min_size=n, max_size=n))
    level = data.draw(st.integers(min_value=0, max_value=9))
    mv = memoryview(raw)
    a = to_png(raw, (w, h), level=level)
    b = to_png(mv, (w, h), level=level)
    assert a == b


@settings(max_examples=300, deadline=None)
@given(edid_data=st.binary(max_size=1024))
def test_parse_edid_never_crashes(edid_data):
    result = parse_edid(edid_data)
    assert isinstance(result, dict)


@settings(max_examples=300, deadline=None)
@given(payload=st.binary(max_size=1024))
def test_parse_edid_text_like_never_crashes(payload):
    blob = bytes(payload)
    result = parse_edid(blob)
    assert isinstance(result, dict)


@settings(max_examples=300, deadline=None)
@given(data=st.data())
def test_from_size_never_crashes(data):
    w = data.draw(st.integers(min_value=1, max_value=32))
    h = data.draw(st.integers(min_value=1, max_value=32))
    n = w * h * 4
    raw = data.draw(st.binary(min_size=n, max_size=n))
    shot = ScreenShot.from_size(raw, w, h)
    assert shot.width == w
    assert shot.height == h


@settings(max_examples=300, deadline=None)
@given(data=st.data())
def test_bgra_never_crashes(data):
    w = data.draw(st.integers(min_value=1, max_value=16))
    h = data.draw(st.integers(min_value=1, max_value=16))
    n = w * h * 4
    raw = data.draw(st.binary(min_size=n, max_size=n))
    shot = ScreenShot.from_size(raw, w, h)
    result = shot.bgra()
    assert isinstance(bytes(result), bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.data())
def test_to_pil_never_crashes(data):
    w = data.draw(st.integers(min_value=1, max_value=16))
    h = data.draw(st.integers(min_value=1, max_value=16))
    n = w * h * 4
    raw = data.draw(st.binary(min_size=n, max_size=n))
    mode = data.draw(st.sampled_from(["RGB", "RGBA"]))
    shot = ScreenShot.from_size(raw, w, h)
    img = shot.to_pil(mode=mode)
    assert img.size == (w, h)


@settings(max_examples=300, deadline=None)
@given(
    left=st.integers(min_value=-10000, max_value=10000),
    top=st.integers(min_value=-10000, max_value=10000),
    width=st.integers(min_value=0, max_value=10000),
    height=st.integers(min_value=0, max_value=10000),
    tag=st.text(max_size=32),
)
def test_as_region_never_crashes(left, top, width, height, tag):
    mon = Monitor(left=left, top=top, width=width, height=height)
    region = mon.as_region()
    assert region["left"] == left
    assert region["top"] == top
    assert region["width"] == width
    assert region["height"] == height
