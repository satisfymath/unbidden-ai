```python
# file: tests/test_unbidden_robustness.py
import pytest
from hypothesis import given, settings
import hypothesis.strategies as st
from rich.markup import escape
from rich.markup import render
from rich.control import strip_control_codes
from rich.control import escape_control_codes
from rich.emoji import Emoji
from rich.cells import cell_len
from rich.cells import cached_cell_len
from rich.cells import split_text


@settings(max_examples=300, deadline=None)
@given(markup=st.text())
def test_escape_never_crashes(markup):
    escape(markup)


@settings(max_examples=300, deadline=None)
@given(markup=st.text())
def test_render_never_crashes(markup):
    render(markup)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_strip_control_codes_never_crashes(text):
    strip_control_codes(text)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_escape_control_codes_never_crashes(text):
    escape_control_codes(text)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_Emoji_replace_never_crashes(text):
    Emoji.replace(text)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_cell_len_never_crashes(text):
    cell_len(text)


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_cached_cell_len_never_crashes(text):
    cached_cell_len(text)


@settings(max_examples=300, deadline=None)
@given(text=st.text(), cell_position=st.integers(min_value=0, max_value=10000))
def test_split_text_never_crashes(text, cell_position):
    split_text(text, cell_position)
```
