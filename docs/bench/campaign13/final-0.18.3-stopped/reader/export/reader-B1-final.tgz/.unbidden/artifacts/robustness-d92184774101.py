from reader._app.legacy import humanize_apnumber
from reader._app.legacy import highlighted
from reader._plugins.legacy.share import percent_encode
from reader.plugins.entry_dedupe import tokenize
from reader.plugins.entry_dedupe import strip_accents
from reader._app.legacy.api_thing import is_safe_url
from reader._app.legacy import humanize_naturaltime
from reader._update.hooks import log_resource_id
from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.integers())
def test_humanize_apnumber_never_crashes(value):
    humanize_apnumber(value)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_highlighted_never_crashes(s):
    highlighted(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text(alphabet=st.characters(min_codepoint=32, max_codepoint=126)))
def test_percent_encode_never_crashes(s):
    percent_encode(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_tokenize_never_crashes(s):
    tokenize(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_accents_never_crashes(s):
    strip_accents(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_is_safe_url_never_crashes(s):
    is_safe_url(s)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes())
def test_humanize_naturaltime_never_crashes(dt):
    humanize_naturaltime(dt)


@settings(max_examples=300, deadline=None)
@given(rid=st.one_of(st.none(), st.tuples(st.text(), st.text()), st.tuples(st.text()), st.tuples()))
def test_log_resource_id_never_crashes(rid):
    log_resource_id(rid)
