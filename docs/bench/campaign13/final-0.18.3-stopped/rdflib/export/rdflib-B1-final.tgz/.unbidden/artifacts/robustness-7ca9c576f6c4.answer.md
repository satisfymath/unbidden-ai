```python
# file: tests/test_unbidden_robustness.py
import hypothesis.strategies as st
from hypothesis import given, settings

from rdflib.compat import cast_bytes
from rdflib.contrib.graphdb.util import sanitize_filename
from rdflib.contrib.graphdb.util import extract_filename_from_content_disposition
from rdflib.plugins.parsers.notation3 import splitFragP
from rdflib.plugins.parsers.notation3 import join
from rdflib.plugins.parsers.ntriples import unquote
from rdflib.plugins.parsers.ntriples import uriquote
from rdflib.namespace import Namespace


@settings(max_examples=300, deadline=None)
@given(s=st.one_of(st.text(), st.binary()))
def test_cast_bytes_round_trips(s):
    result = cast_bytes(s)
    assert isinstance(result, bytes)
    if isinstance(s, str):
        assert result.decode("utf-8") == s


@settings(max_examples=300, deadline=None)
@given(filename=st.text())
def test_sanitize_filename_never_crashes(filename):
    result = sanitize_filename(filename)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(header=st.text())
def test_extract_filename_from_content_disposition_never_crashes(header):
    result = extract_filename_from_content_disposition(header)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(uriref=st.text(), punc=st.integers(min_value=-1000000, max_value=1000000))
def test_splitFragP_never_crashes(uriref, punc):
    result = splitFragP(uriref, punc)
    assert isinstance(result, tuple)


@settings(max_examples=300, deadline=None)
@given(here=st.text(), there=st.text())
def test_join_never_crashes(here, there):
    result = join(here, there)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    result = unquote(s)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(uri=st.text())
def test_uriquote_round_trips(uri):
    quoted = uriquote(uri)
    assert isinstance(quoted, str)
    assert unquote(quoted) == uri


@settings(max_examples=300, deadline=None)
@given(name=st.text())
def test_term_never_crashes(name):
    ns = Namespace("http://example.org/")
    result = ns.term(name)
    assert result is not None
```
