import datetime as dt

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st
from humanize.filesize import naturalsize  # def naturalsize(value: float | str, binary: bool=False, gnu: bool=False, format: str='%.1f') — Format a number of bytes like a human-readable filesize (e.g. 10 kB).
from humanize.number import ordinal  # def ordinal(value: NumberOrString, gender: str='male') — Converts an integer to its ordinal as a string.
from humanize.number import intcomma  # def intcomma(value: NumberOrString, ndigits: int | None=None) — Converts an integer to a string containing commas every three digits.
from humanize.number import intword  # def intword(value: NumberOrString, format: str='%.1f') — Converts a large integer to a friendly text representation.
from humanize.number import apnumber  # def apnumber(value: NumberOrString) — Converts an integer to Associated Press style.
from humanize.number import fractional  # def fractional(value: NumberOrString) — Convert to fractional number.
from humanize.time import naturaldelta  # def naturaldelta(value: dt.timedelta | float, months: bool=True, minimum_unit: str='seconds') — Return a natural representation of a timedelta or number of seconds.
from humanize.lists import natural_list  # def natural_list(items: Iterable[Any]) — Natural list.

_valid_formats = st.sampled_from(["%.1f", "%.2f", "%.0f", "%d", "%.3f"])
_valid_minimum_units = st.sampled_from(["seconds", "minutes", "hours", "days", "months", "years"])
_numeric_text = st.from_regex(r"-?[0-9]{1,18}", fullmatch=True)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.floats(min_value=-1e30, max_value=1e30, allow_nan=False, allow_infinity=False),
        _numeric_text,
        st.just("0"),
        st.just(""),
    ).filter(lambda x: x != ""),
    binary=st.booleans(),
    gnu=st.booleans(),
    format=_valid_formats,
)
def test_naturalsize_never_crashes(value, binary, gnu, format):
    result = naturalsize(value, binary=binary, gnu=gnu, format=format)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**18, max_value=10**18),
        _numeric_text,
        st.integers(min_value=-10**18, max_value=10**18).map(str),
    ),
    gender=st.sampled_from(["male", "female"]),
)
def test_ordinal_never_crashes(value, gender):
    result = ordinal(value, gender=gender)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.integers(min_value=-10**30, max_value=10**30).map(str),
        st.floats(min_value=-1e15, max_value=1e15, allow_nan=False, allow_infinity=False),
    ),
    ndigits=st.one_of(st.none(), st.integers(min_value=0, max_value=10)),
)
def test_intcomma_never_crashes(value, ndigits):
    result = intcomma(value, ndigits=ndigits)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**30, max_value=10**30),
        st.integers(min_value=-10**30, max_value=10**30).map(str),
        st.floats(min_value=-1e30, max_value=1e30, allow_nan=False, allow_infinity=False),
    ),
    format=_valid_formats,
)
def test_intword_never_crashes(value, format):
    result = intword(value, format=format)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**18, max_value=10**18),
        st.integers(min_value=0, max_value=20),
        st.integers(min_value=-100, max_value=100).map(str),
    )
)
def test_apnumber_never_crashes(value):
    result = apnumber(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.integers(min_value=-10**12, max_value=10**12),
        st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
        _numeric_text,
    )
)
def test_fractional_never_crashes(value):
    result = fractional(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False),
        st.integers(min_value=-10**9, max_value=10**9).map(float),
        st.timedeltas(min_value=dt.timedelta(days=-10000), max_value=dt.timedelta(days=10000)),
    ),
    months=st.booleans(),
    minimum_unit=_valid_minimum_units,
)
def test_naturaldelta_never_crashes(value, months, minimum_unit):
    result = naturaldelta(value, months=months, minimum_unit=minimum_unit)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(items=st.lists(st.text(), min_size=0, max_size=10))
def test_natural_list_never_crashes(items):
    result = natural_list(items)
    assert isinstance(result, str)
