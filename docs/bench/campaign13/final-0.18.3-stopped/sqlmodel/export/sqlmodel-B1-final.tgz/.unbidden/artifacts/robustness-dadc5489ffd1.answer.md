```python
# file: tests/test_unbidden_robustness.py
from docs_src.tutorial.fastapi.update.tutorial002_py310 import hash_password
from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_hash_password_never_crashes(password):
    hash_password(password)
```