import datetime

import hypothesis.strategies as st
from hypothesis import given, settings

from marshmallow.utils import ensure_text_type
from marshmallow.utils import from_timestamp
from marshmallow.utils import is_generator
from marshmallow.utils import is_iterable_but_not_string
from marshmallow.orderedset import OrderedSet
from marshmallow.fields import Field
from marshmallow.schema import Schema
from marshmallow.exceptions import ValidationError


@settings(max_examples=300, deadline=None)
@given(st.one_of(st.text(), st.text().map(lambda s: s.encode("utf-8"))))
def test_ensure_text_type_never_crashes(val):
    result = ensure_text_type(val)
    assert isinstance(result, str)
    if isinstance(val, str):
        assert result == val
    else:
        assert result == val.decode("utf-8")


@settings(max_examples=300, deadline=None)
@given(
    st.one_of(
        st.integers(min_value=-2000000000, max_value=2000000000),
        st.floats(
            allow_nan=False, allow_infinity=False, min_value=-2000000000.0, max_value=2000000000.0
        ),
    )
)
def test_from_timestamp_never_crashes(val):
    result = from_timestamp(val)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(
    st.one_of(
        st.text(),
        st.integers(),
        st.none(),
        st.booleans(),
        st.lists(st.integers()),
        st.dictionaries(st.text(), st.integers()),
        st.binary(),
    )
)
def test_is_generator_never_crashes(val):
    result = is_generator(val)
    assert isinstance(result, bool)
    assert result is False


@settings(max_examples=300, deadline=None)
@given(
    st.one_of(
        st.text(),
        st.binary(),
        st.integers(),
        st.lists(st.text()),
        st.dictionaries(st.text(), st.text()),
        st.tuples(st.integers()),
        st.none(),
    )
)
def test_is_iterable_but_not_string_never_crashes(val):
    result = is_iterable_but_not_string(val)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(st.text())
def test_add_never_crashes(val):
    s = OrderedSet()
    s.add(val)
    assert val in s
    assert len(s) == 1


@settings(max_examples=300, deadline=None)
@given(st.one_of(st.text(), st.integers(), st.booleans(), st.none(), st.floats(allow_nan=False, allow_infinity=False)))
def test_deserialize_never_crashes(val):
    f = Field()
    result = f.deserialize(val)
    assert result == val


@settings(max_examples=300, deadline=None)
@given(
    st.dictionaries(
        st.text(),
        st.one_of(st.text(), st.integers(), st.booleans(), st.none(), st.floats(allow_nan=False, allow_infinity=False)),
    )
)
def test_load_never_crashes(val):
    schema = Schema()
    result = schema.load(val, unknown="exclude")
    assert isinstance(result, dict)


@settings(max_examples=300, deadline=None)
@given(st.text())
def test_messages_dict_never_crashes(val):
    err = ValidationError(val)
    result = err.messages_dict
    assert isinstance(result, dict)
