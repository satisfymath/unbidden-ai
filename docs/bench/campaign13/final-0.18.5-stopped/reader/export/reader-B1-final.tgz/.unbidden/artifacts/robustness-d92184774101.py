from hypothesis import given, settings, strategies as st

from reader._app.legacy import highlighted
from reader._app.legacy import humanize_apnumber
from reader._app.legacy import toyaml
from reader._app.legacy.api_thing import is_safe_url
from reader._plugins.legacy.share import percent_encode
from reader._update.hooks import log_resource_id
from reader.plugins.entry_dedupe import strip_accents
from reader.plugins.entry_dedupe import tokenize


@settings(max_examples=300, deadline=None)
@given(value=st.integers(min_value=-(10**12), max_value=10**12))
def test_humanize_apnumber_never_crashes(value):
    humanize_apnumber(value)


@settings(max_examples=300, deadline=None)
@given(string=st.text())
def test_highlighted_never_crashes(string):
    highlighted(string)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_percent_encode_never_crashes(s):
    percent_encode(s)


@settings(max_examples=300, deadline=None)
@given(resource_id=st.one_of(st.none(), st.lists(st.text(), max_size=4).map(tuple)))
def test_log_resource_id_never_crashes(resource_id):
    log_resource_id(resource_id)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_tokenize_never_crashes(s):
    tokenize(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_strip_accents_never_crashes(s):
    strip_accents(s)


@settings(max_examples=300, deadline=None)
@given(data=st.one_of(st.text(), st.integers(min_value=-(10**12), max_value=10**12), st.none()))
def test_toyaml_never_crashes(data):
    toyaml(data)


@settings(max_examples=300, deadline=None)
@given(target=st.text())
def test_is_safe_url_never_crashes(target):
    is_safe_url(target)
