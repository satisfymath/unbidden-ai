import datetime

from hypothesis import given, settings
import hypothesis.strategies as st

from app.api.dependencies.articles import get_articles_filters
from app.models.domain.rwmodel import convert_field_to_camel_case
from app.models.domain.rwmodel import convert_datetime_to_realworld
from app.services.articles import get_slug_for_article
from app.services.jwt import create_jwt_token
from app.services.jwt import get_username_from_token
from app.services.security import verify_password
from app.services.security import get_password_hash


@settings(max_examples=300, deadline=None)
@given(
    tag=st.one_of(st.none(), st.text()),
    author=st.one_of(st.none(), st.text()),
    favorited=st.one_of(st.none(), st.text()),
    limit=st.integers(),
    offset=st.integers(),
)
def test_get_articles_filters_never_crashes(tag, author, favorited, limit, offset):
    get_articles_filters(tag=tag, author=author, favorited=favorited, limit=limit, offset=offset)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_convert_field_to_camel_case_never_crashes(s):
    convert_field_to_camel_case(s)


@settings(max_examples=300, deadline=None)
@given(title=st.text())
def test_get_slug_for_article_never_crashes(title):
    get_slug_for_article(title)


@settings(max_examples=300, deadline=None)
@given(
    jwt_content=st.dictionaries(st.text(), st.text()),
    secret_key=st.text(),
    expires_delta=st.timedeltas(),
)
def test_create_jwt_token_never_crashes(jwt_content, secret_key, expires_delta):
    create_jwt_token(jwt_content=jwt_content, secret_key=secret_key, expires_delta=expires_delta)


@settings(max_examples=300, deadline=None)
@given(token=st.text(), secret_key=st.text())
def test_get_username_from_token_never_crashes(token, secret_key):
    get_username_from_token(token, secret_key)


@settings(max_examples=300, deadline=None)
@given(plain=st.text(), hashed=st.text())
def test_verify_password_never_crashes(plain, hashed):
    verify_password(plain, hashed)


@settings(max_examples=300, deadline=None)
@given(password=st.text())
def test_get_password_hash_round_trips(password):
    hashed = get_password_hash(password)
    assert verify_password(password, hashed)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes())
def test_convert_datetime_to_realworld_never_crashes(dt):
    convert_datetime_to_realworld(dt)
