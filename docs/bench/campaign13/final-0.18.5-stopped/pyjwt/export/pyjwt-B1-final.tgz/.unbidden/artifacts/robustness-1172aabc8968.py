from jwt.algorithms import HMACAlgorithm
from jwt.jwk_set_cache import JWKSetCache
from jwt.utils import base64url_decode
from jwt.utils import base64url_encode
from jwt.utils import bytes_to_number
from jwt.utils import force_bytes
from jwt.utils import from_base64url_uint
from jwt.utils import to_base64url_uint
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(st.text(), st.binary()))
def test_force_bytes_never_crashes(value):
    result = force_bytes(value)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_encode_never_crashes(data):
    result = base64url_encode(data)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_bytes_to_number_never_crashes(data):
    result = bytes_to_number(data)
    assert isinstance(result, int)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_base64url_decode_round_trips(data):
    encoded = base64url_encode(data)
    decoded = base64url_decode(encoded)
    assert decoded == data


@settings(max_examples=300, deadline=None)
@given(value=st.integers(min_value=0, max_value=2**4096))
def test_to_base64url_uint_round_trips(value):
    encoded = to_base64url_uint(value)
    decoded = from_base64url_uint(encoded)
    assert decoded == value


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.binary()))
def test_prepare_key_never_crashes(key):
    alg = HMACAlgorithm(HMACAlgorithm.SHA256)
    result = alg.prepare_key(key)
    assert isinstance(result, bytes)


@settings(max_examples=300, deadline=None)
@given(
    payload=st.one_of(
        st.none(),
        st.dictionaries(
            st.text(),
            st.one_of(
                st.text(),
                st.integers(min_value=-(2**256), max_value=2**256),
                st.booleans(),
                st.none(),
            ),
        ),
    )
)
def test_put_never_crashes(payload):
    cache = JWKSetCache(60)
    cache.put(payload)


@settings(max_examples=300, deadline=None)
@given(key=st.one_of(st.text(), st.binary()))
def test_to_jwk_never_crashes(key):
    alg = HMACAlgorithm(HMACAlgorithm.SHA256)
    result = alg.to_jwk(key, as_dict=True)
    assert isinstance(result, dict)
