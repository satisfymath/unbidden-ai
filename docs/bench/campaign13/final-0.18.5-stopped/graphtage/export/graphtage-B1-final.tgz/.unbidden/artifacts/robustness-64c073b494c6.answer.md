```python
# file: tests/test_unbidden_robustness.py
from graphtage.batch_distance import all_flat
from graphtage.batch_distance import all_pairs
from graphtage.batch_distance import cost
from graphtage.git import split_options
from graphtage.graphtage import StringFormatter
from graphtage.graphtage import string_edit_distance
from graphtage.levenshtein import exact_string_distance
from graphtage.levenshtein import levenshtein_distance
from hypothesis import given
from hypothesis import settings
import hypothesis.strategies as st


_text_small = st.text(max_size=20)
_text_list = st.lists(st.text(max_size=10), max_size=5)
_bytes_small = st.binary(max_size=20)
_str_or_bytes = st.one_of(st.text(max_size=20), st.binary(max_size=20))
_str_or_bytes_list = st.lists(st.one_of(st.text(max_size=10), st.binary(max_size=10)), max_size=4)

_formatter = StringFormatter()


@settings(max_examples=300, deadline=None)
@given(s=_text_small, t=_text_small)
def test_levenshtein_distance_never_crashes(s, t):
    d = levenshtein_distance(s, t)
    assert isinstance(d, int)
    assert d >= 0


@settings(max_examples=300, deadline=None)
@given(s=_text_small, t=_text_small)
def test_exact_string_distance_never_crashes(s, t):
    d = exact_string_distance(s, t)
    assert isinstance(d, int)
    assert d >= 0


@settings(max_examples=300, deadline=None)
@given(s=_text_small, t=_text_small)
def test_string_edit_distance_never_crashes(s, t):
    d = string_edit_distance(s, t)
    assert d >= 0


@settings(max_examples=300, deadline=None)
@given(a=_str_or_bytes, b=_str_or_bytes)
def test_cost_never_crashes(a, b):
    d = cost(a, b)
    assert isinstance(d, int)
    assert d >= 0


@settings(max_examples=300, deadline=None)
@given(a=_str_or_bytes_list, b=_str_or_bytes_list)
def test_all_pairs_never_crashes(a, b):
    result = all_pairs(list(a), list(b))
    assert result is not None


@settings(max_examples=300, deadline=None)
@given(a=_str_or_bytes_list, b=_str_or_bytes_list)
def test_all_flat_never_crashes(a, b):
    n = min(len(a), len(b))
    result = all_flat(list(a)[:n], list(b)[:n])
    assert result is not None


@settings(max_examples=300, deadline=None)
@given(argv=st.lists(st.text(max_size=30), max_size=10))
def test_split_options_never_crashes(argv):
    split_options(list(argv))


@settings(max_examples=300, deadline=None)
@given(c=st.characters())
def test_escape_never_crashes(c):
    _formatter.escape(c)
```
