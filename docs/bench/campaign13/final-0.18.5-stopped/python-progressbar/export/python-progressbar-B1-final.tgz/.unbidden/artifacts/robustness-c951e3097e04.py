import datetime
import io

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st
from progressbar.utils import no_color
from progressbar.utils import len_color
from progressbar.widgets import format_unit_value
from progressbar.utils import deltas_to_seconds
from progressbar.env import env_flag
from progressbar.widgets import string_or_lambda
from progressbar.widgets import create_wrapper
from progressbar.widgets import create_marker


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_no_color_never_crashes(value):
    result = no_color(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_len_color_never_crashes(value):
    result = len_color(value)
    assert result == len(no_color(value))
    assert result >= 0


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        st.none(),
        st.integers(),
        st.floats(allow_nan=False, allow_infinity=False),
    ),
    unit=st.text(),
    unit_scale=st.booleans(),
)
def test_format_unit_value_never_crashes(value, unit, unit_scale):
    result = format_unit_value(value, unit=unit, unit_scale=unit_scale)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    deltas=st.lists(
        st.one_of(
            st.none(),
            st.integers(),
            st.floats(allow_nan=False, allow_infinity=False),
            st.timedeltas(),
        ),
        max_size=5,
    ),
    default=st.integers(),
)
def test_deltas_to_seconds_never_crashes(deltas, default):
    result = deltas_to_seconds(*deltas, default=default)
    assert isinstance(result, (int, float))


@settings(max_examples=300, deadline=None)
@given(
    name=st.text().filter(lambda s: "\x00" not in s),
    default=st.one_of(st.booleans(), st.none()),
)
def test_env_flag_never_crashes(name, default):
    result = env_flag(name, default)
    assert result is None or isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_string_or_lambda_never_crashes(value):
    result = string_or_lambda(value)
    assert callable(result)


@settings(max_examples=300, deadline=None)
@given(
    wrapper_arg=st.one_of(
        st.none(),
        st.text(),
        st.tuples(
            st.one_of(st.none(), st.text()),
            st.one_of(st.none(), st.text()),
        ),
    )
)
def test_create_wrapper_never_crashes(wrapper_arg):
    result = create_wrapper(wrapper_arg)
    assert result is None or isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    marker=st.text(),
    wrap=st.one_of(
        st.none(),
        st.text(),
        st.tuples(
            st.one_of(st.none(), st.text()),
            st.one_of(st.none(), st.text()),
        ),
    ),
)
def test_create_marker_never_crashes(marker, wrap):
    result = create_marker(marker, wrap=wrap)
    assert callable(result)
