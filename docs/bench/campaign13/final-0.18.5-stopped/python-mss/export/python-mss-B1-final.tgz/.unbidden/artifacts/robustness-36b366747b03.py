from mss.buffer import finalizing_buffer  # noqa: F401  # keep import surface stable
from mss.exception import ScreenShotError
from mss.linux import choose_impl
from mss.linux.xcb import connect
from mss.models import Monitor
from mss.screenshot import ScreenShot
from mss.tools import parse_edid
from mss.tools import to_png

from hypothesis import assume, given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(data_obj=st.data())
def test_to_png_never_crashes(data_obj):
    w = data_obj.draw(st.integers(min_value=1, max_value=32))
    h = data_obj.draw(st.integers(min_value=1, max_value=32))
    level = data_obj.draw(st.integers(min_value=0, max_value=9))
    n = w * h * 3
    data = data_obj.draw(st.binary(min_size=n, max_size=n))
    to_png(data, (w, h), level=level, output=None)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_parse_edid_never_crashes(data):
    parse_edid(data)


@settings(max_examples=300, deadline=None)
@given(data_obj=st.data())
def test_from_size_never_crashes(data_obj):
    width = data_obj.draw(st.integers(min_value=0, max_value=32))
    height = data_obj.draw(st.integers(min_value=0, max_value=32))
    n = width * height * 4
    data = data_obj.draw(st.binary(min_size=n, max_size=n))
    ScreenShot.from_size(data, width, height)


@settings(max_examples=300, deadline=None)
@given(data_obj=st.data())
def test_to_pil_never_crashes(data_obj):
    width = data_obj.draw(st.integers(min_value=0, max_value=32))
    height = data_obj.draw(st.integers(min_value=0, max_value=32))
    n = width * height * 4
    data = data_obj.draw(st.binary(min_size=n, max_size=n))
    shot = ScreenShot.from_size(data, width, height)
    try:
        shot.to_pil()
    except ImportError:
        assume(False)


@settings(max_examples=300, deadline=None)
@given(data_obj=st.data())
def test_bgra_never_crashes(data_obj):
    width = data_obj.draw(st.integers(min_value=0, max_value=32))
    height = data_obj.draw(st.integers(min_value=0, max_value=32))
    n = width * height * 4
    data = data_obj.draw(st.binary(min_size=n, max_size=n))
    shot = ScreenShot.from_size(data, width, height)
    attr = getattr(shot, "bgra")
    if callable(attr):
        attr()
    else:
        attr


@settings(max_examples=300, deadline=None)
@given(backend=st.sampled_from(["xcb", "xrandr"]))
def test_choose_impl_never_crashes(backend):
    choose_impl(backend)


@settings(max_examples=300, deadline=None)
@given(display=st.none() | st.text())
def test_connect_never_crashes(display):
    try:
        connect(display)
    except ScreenShotError:
        pass


@settings(max_examples=300, deadline=None)
@given(
    left=st.integers(min_value=-1000000, max_value=1000000),
    top=st.integers(min_value=-1000000, max_value=1000000),
    width=st.integers(min_value=-1000000, max_value=1000000),
    height=st.integers(min_value=-1000000, max_value=1000000),
)
def test_as_region_never_crashes(left, top, width, height):
    mon = Monitor(left=left, top=top, width=width, height=height)
    mon.as_region()
