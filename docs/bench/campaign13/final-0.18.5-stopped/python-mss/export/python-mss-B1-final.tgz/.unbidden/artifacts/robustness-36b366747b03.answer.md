```python
# file: tests/test_unbidden_robustness.py
from mss.buffer import finalizing_buffer  # noqa: F401  # keep import surface stable
from mss.linux import choose_impl
from mss.linux.xcb import connect
from mss.models import Monitor
from mss.screenshot import ScreenShot
from mss.tools import parse_edid
from mss.tools import to_png

from hypothesis import given, settings, strategies as st


@settings(max_examples=300, deadline=None)
@given(
    data=st.binary(),
    w=st.integers(min_value=-1000000, max_value=1000000),
    h=st.integers(min_value=-1000000, max_value=1000000),
    level=st.integers(min_value=-100, max_value=100),
)
def test_to_png_never_crashes(data, w, h, level):
    to_png(data, (w, h), level=level, output=None)


@settings(max_examples=300, deadline=None)
@given(data=st.binary())
def test_parse_edid_never_crashes(data):
    parse_edid(data)


@settings(max_examples=300, deadline=None)
@given(
    data=st.binary(),
    width=st.integers(min_value=-1000000, max_value=1000000),
    height=st.integers(min_value=-1000000, max_value=1000000),
)
def test_from_size_never_crashes(data, width, height):
    ScreenShot.from_size(data, width, height)


@settings(max_examples=300, deadline=None)
@given(
    data=st.binary(),
    width=st.integers(min_value=-100, max_value=100),
    height=st.integers(min_value=-100, max_value=100),
    mode=st.text(),
)
def test_to_pil_never_crashes(data, width, height, mode):
    shot = ScreenShot.from_size(data, width, height)
    shot.to_pil(mode)


@settings(max_examples=300, deadline=None)
@given(
    data=st.binary(),
    width=st.integers(min_value=-100, max_value=100),
    height=st.integers(min_value=-100, max_value=100),
)
def test_bgra_never_crashes(data, width, height):
    shot = ScreenShot.from_size(data, width, height)
    attr = getattr(shot, "bgra")
    if callable(attr):
        attr()
    else:
        attr


@settings(max_examples=300, deadline=None)
@given(backend=st.text())
def test_choose_impl_never_crashes(backend):
    choose_impl(backend)


@settings(max_examples=300, deadline=None)
@given(display=st.none() | st.text() | st.binary())
def test_connect_never_crashes(display):
    connect(display)


@settings(max_examples=300, deadline=None)
@given(
    left=st.integers(min_value=-1000000, max_value=1000000),
    top=st.integers(min_value=-1000000, max_value=1000000),
    width=st.integers(min_value=-1000000, max_value=1000000),
    height=st.integers(min_value=-1000000, max_value=1000000),
)
def test_as_region_never_crashes(left, top, width, height):
    mon = Monitor(left=left, top=top, width=width, height=height)
    mon.as_region()
```
