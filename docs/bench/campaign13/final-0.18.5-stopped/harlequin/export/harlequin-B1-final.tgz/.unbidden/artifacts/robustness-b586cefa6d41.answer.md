```python
# file: tests/test_unbidden_robustness.py
from pathlib import Path

from hypothesis import given, settings, strategies as st

from harlequin.autocomplete.symbols import find_symbols
from harlequin.bindings import key_needs_priority
from harlequin.exception import pretty_print_warning
from harlequin.export import file_suffix
from harlequin.export import names_a_directory
from harlequin.external import split_command
from harlequin.hsql.output import is_layout
from harlequin.hsql.output import suffix


@settings(max_examples=300, deadline=None)
@given(text=st.text())
def test_find_symbols_never_crashes(text):
    find_symbols(text)


@settings(max_examples=300, deadline=None)
@given(key=st.text())
def test_key_needs_priority_never_crashes(key):
    key_needs_priority(key)


@settings(max_examples=300, deadline=None)
@given(format_name=st.text())
def test_file_suffix_never_crashes(format_name):
    file_suffix(format_name)


@settings(max_examples=300, deadline=None)
@given(destination=st.one_of(st.text(), st.text().map(Path)))
def test_names_a_directory_never_crashes(destination):
    names_a_directory(destination)


@settings(max_examples=300, deadline=None)
@given(command=st.text())
def test_split_command_never_crashes(command):
    split_command(command)


@settings(max_examples=300, deadline=None)
@given(title=st.text(), message=st.text())
def test_pretty_print_warning_never_crashes(title, message):
    pretty_print_warning(title, message)


@settings(max_examples=300, deadline=None)
@given(format_name=st.text())
def test_is_layout_never_crashes(format_name):
    is_layout(format_name)


@settings(max_examples=300, deadline=None)
@given(format_name=st.text())
def test_suffix_never_crashes(format_name):
    suffix(format_name)
```
