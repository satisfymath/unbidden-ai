import datetime as dt

import pytest
from hypothesis import given, settings
import hypothesis.strategies as st

from humanize.filesize import naturalsize  # def naturalsize(value: float | str, binary: bool=False, gnu: bool=False, format: str='%.1f') — Format a number of bytes like a human-readable filesize (e.g. 10 kB).
from humanize.number import ordinal  # def ordinal(value: NumberOrString, gender: str='male') — Converts an integer to its ordinal as a string.
from humanize.number import intcomma  # def intcomma(value: NumberOrString, ndigits: int | None=None) — Converts an integer to a string containing commas every three digits.
from humanize.number import intword  # def intword(value: NumberOrString, format: str='%.1f') — Converts a large integer to a friendly text representation.
from humanize.number import apnumber  # def apnumber(value: NumberOrString) — Converts an integer to Associated Press style.
from humanize.number import fractional  # def fractional(value: NumberOrString) — Convert to fractional number.
from humanize.time import naturaldelta  # def naturaldelta(value: dt.timedelta | float, months: bool=True, minimum_unit: str='seconds') — Return a natural representation of a timedelta or number of seconds.
from humanize.lists import natural_list  # def natural_list(items: Iterable[Any]) — Natural list.


_valid_formats = st.sampled_from(["%.1f", "%.0f", "%.2f", "%d", "%.3f"])
_numeric_string = st.from_regex(r"-?\d{1,10}(\.\d{1,5})?", fullmatch=True)
_safe_int = st.integers(min_value=-10**12, max_value=10**12)
_safe_float = st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False, width=64)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(_safe_int, _safe_float, _numeric_string),
    binary=st.booleans(),
    gnu=st.booleans(),
    format=_valid_formats,
)
def test_naturalsize_never_crashes(value, binary, gnu, format):
    result = naturalsize(value, binary=binary, gnu=gnu, format=format)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(_safe_int, _numeric_string),
    gender=st.sampled_from(["male", "female"]),
)
def test_ordinal_never_crashes(value, gender):
    result = ordinal(value, gender=gender)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(_safe_int, _safe_float, _numeric_string),
    ndigits=st.one_of(st.none(), st.integers(min_value=0, max_value=10)),
)
def test_intcomma_never_crashes(value, ndigits):
    result = intcomma(value, ndigits=ndigits)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(_safe_int, _safe_float, _numeric_string),
    format=_valid_formats,
)
def test_intword_never_crashes(value, format):
    result = intword(value, format=format)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(_safe_int, _numeric_string))
def test_apnumber_never_crashes(value):
    result = apnumber(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(value=st.one_of(_safe_int, _safe_float, _numeric_string))
def test_fractional_never_crashes(value):
    result = fractional(value)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(
    value=st.one_of(
        _safe_float,
        st.timedeltas(min_value=dt.timedelta(days=-365000), max_value=dt.timedelta(days=365000)),
    ),
    months=st.booleans(),
    minimum_unit=st.sampled_from(["years", "months", "days", "hours", "minutes", "seconds"]),
)
def test_naturaldelta_never_crashes(value, months, minimum_unit):
    result = naturaldelta(value, months=months, minimum_unit=minimum_unit)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(items=st.lists(st.text(), max_size=10))
def test_natural_list_never_crashes(items):
    result = natural_list(items)
    assert isinstance(result, str)
