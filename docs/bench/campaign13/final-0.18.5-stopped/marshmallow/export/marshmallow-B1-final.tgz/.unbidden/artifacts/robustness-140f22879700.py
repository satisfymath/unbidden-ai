import datetime
import json

from hypothesis import given, settings
import hypothesis.strategies as st

from marshmallow.utils import from_timestamp
from marshmallow.utils import from_timestamp_ms
from marshmallow.utils import timestamp
from marshmallow.utils import timestamp_ms
from marshmallow.utils import ensure_text_type
from marshmallow.utils import is_generator
from marshmallow.utils import is_iterable_but_not_string
from marshmallow.error_store import copy_containers


@settings(max_examples=300, deadline=None)
@given(val=st.one_of(st.text(), st.builds(lambda s: s.encode("utf-8"), st.text())))
def test_ensure_text_type_never_crashes(val):
    result = ensure_text_type(val)
    assert isinstance(result, str)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes(min_value=datetime.datetime(1970, 1, 1), max_value=datetime.datetime(2030, 1, 1)))
def test_timestamp_never_crashes(dt):
    result = timestamp(dt)
    assert isinstance(result, float)


@settings(max_examples=300, deadline=None)
@given(dt=st.datetimes(min_value=datetime.datetime(1970, 1, 1), max_value=datetime.datetime(2030, 1, 1)))
def test_timestamp_ms_never_crashes(dt):
    result = timestamp_ms(dt)
    assert isinstance(result, int)


@settings(max_examples=300, deadline=None)
@given(v=st.floats(min_value=-1e9, max_value=1e9, allow_nan=False, allow_infinity=False))
def test_from_timestamp_never_crashes(v):
    result = from_timestamp(v)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(v=st.floats(min_value=-1e12, max_value=1e12, allow_nan=False, allow_infinity=False))
def test_from_timestamp_ms_never_crashes(v):
    result = from_timestamp_ms(v)
    assert isinstance(result, datetime.datetime)


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.integers(), st.text(), st.lists(st.integers()), st.dictionaries(st.text(), st.integers()), st.tuples(st.integers()), st.just((x for x in [])), st.just(iter([]))))
def test_is_generator_never_crashes(obj):
    result = is_generator(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(obj=st.one_of(st.integers(), st.text(), st.binary(), st.lists(st.text()), st.dictionaries(st.text(), st.text()), st.tuples(st.text()), st.sets(st.integers())))
def test_is_iterable_but_not_string_never_crashes(obj):
    result = is_iterable_but_not_string(obj)
    assert isinstance(result, bool)


@settings(max_examples=300, deadline=None)
@given(errors=st.recursive(st.dictionaries(st.text(), st.text()), lambda c: st.one_of(st.lists(c), st.dictionaries(st.text(), c)), max_leaves=5))
def test_copy_containers_never_crashes(errors):
    result = copy_containers(errors)
    assert result is not None
