from dooit.backport.migrate_from_v2 import parse_recurrence
from dooit.backport.migrate_from_v2 import parse_due
from dooit.utils.date_parser import parse
from dooit.ui.widgets.inputs.model_inputs import Recurrence
from dooit.ui.api.event_handlers import timer
from dooit.ui.api.api_components.vars import VarManager
from dooit.ui.api.api_components.formatters.formatter_store import FormatterStore
from dooit.utils.css_manager import CssManager

from hypothesis import given, settings
import hypothesis.strategies as st


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_recurrence_never_crashes(value):
    parse_recurrence(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_due_never_crashes(value):
    parse_due(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_never_crashes(value):
    parse(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_parse_recurrence_never_crashes(value):
    Recurrence.parse_recurrence(value)


@settings(max_examples=300, deadline=None)
@given(value=st.floats(allow_nan=True, allow_infinity=True))
def test_timer_never_crashes(value):
    timer(value)


@settings(max_examples=300, deadline=None)
@given(value=st.booleans())
def test_always_expand_workspaces_never_crashes(value):
    VarManager().always_expand_workspaces(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_get_formatter_by_id_never_crashes(value):
    FormatterStore().get_formatter_by_id(value)


@settings(max_examples=300, deadline=None)
@given(value=st.text())
def test_inject_css_never_crashes(value):
    CssManager().inject_css(value)
