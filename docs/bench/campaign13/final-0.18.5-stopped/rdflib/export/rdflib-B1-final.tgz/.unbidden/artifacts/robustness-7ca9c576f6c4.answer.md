```python
# file: tests/test_unbidden_robustness.py
from rdflib.compat import cast_bytes
from rdflib.compat import decodeUnicodeEscape
from rdflib.contrib.graphdb.util import sanitize_filename
from rdflib.contrib.graphdb.util import extract_filename_from_content_disposition
from rdflib.plugins.parsers.notation3 import splitFragP
from rdflib.plugins.parsers.notation3 import join
from rdflib.plugins.parsers.ntriples import unquote
from rdflib.plugins.parsers.ntriples import uriquote

import hypothesis.strategies as st
from hypothesis import given, settings


@settings(max_examples=300, deadline=None)
@given(s=st.one_of(st.text(), st.binary()), enc=st.sampled_from(["utf-8", "utf-16", "latin-1"]))
def test_cast_bytes_never_crashes(s, enc):
    cast_bytes(s, enc)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_cast_bytes_round_trips(s):
    assert cast_bytes(s, "utf-8").decode("utf-8") == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_decodeUnicodeEscape_never_crashes(s):
    decodeUnicodeEscape(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_sanitize_filename_never_crashes(s):
    sanitize_filename(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_extract_filename_from_content_disposition_never_crashes(s):
    extract_filename_from_content_disposition(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text(), p=st.integers(min_value=-1000, max_value=1000))
def test_splitFragP_never_crashes(s, p):
    splitFragP(s, p)


@settings(max_examples=300, deadline=None)
@given(a=st.text(), b=st.text())
def test_join_never_crashes(a, b):
    join(a, b)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    unquote(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_uriquote_never_crashes(s):
    uriquote(s)
```
