from hypothesis import given, settings, strategies as st
from oauthlib.common import log_safe
from oauthlib.common import quote
from oauthlib.common import unquote
from oauthlib.common import generate_token
from oauthlib.common import generate_client_id
from oauthlib.oauth1.rfc5849.signature import signature_base_string
from oauthlib.oauth1.rfc5849.signature import base_string_uri
from oauthlib.oauth2.rfc6749.utils import list_to_scope
from oauthlib.oauth2.rfc6749.utils import scope_to_list


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_quote_round_trips(s):
    assert unquote(quote(s)) == s


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_unquote_never_crashes(s):
    unquote(s)


@settings(max_examples=300, deadline=None)
@given(s=st.text())
def test_log_safe_never_crashes(s):
    log_safe(s)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=1000))
def test_generate_token_never_crashes(length):
    generate_token(length)


@settings(max_examples=300, deadline=None)
@given(length=st.integers(min_value=0, max_value=1000))
def test_generate_client_id_never_crashes(length):
    generate_client_id(length)


@settings(max_examples=300, deadline=None)
@given(method=st.text(), uri=st.text(), params=st.text())
def test_signature_base_string_never_crashes(method, uri, params):
    signature_base_string(method, uri, params)


@settings(max_examples=300, deadline=None)
@given(uri=st.text(), host=st.none() | st.text())
def test_base_string_uri_never_crashes(uri, host):
    try:
        base_string_uri(uri, host)
    except ValueError:
        pass


@settings(max_examples=300, deadline=None)
@given(scope=st.lists(st.text(alphabet=st.characters(exclude_characters=[" ", "\t", "\n", "\r"]), min_size=1), min_size=1, max_size=10))
def test_list_to_scope_round_trips(scope):
    assert scope_to_list(list_to_scope(scope)) == scope
